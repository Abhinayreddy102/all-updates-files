<?php
require_once 'gsr_environment.php';
require_once GSR_DOCUMENT_ROOT . '/gsr/common/class/gsr_sqlsrv_db_class.php';
header('Content-Type: application/json; charset=utf-8');
$user_id = 'guest';
if (!empty($_SERVER['HTTP_REMOTE_USER'])) {
    $user_id = $_SERVER['HTTP_REMOTE_USER'];
} elseif (!empty($_SERVER['HTTP_REMOTE_ADLOGON'])) {
    $user_id = $_SERVER['HTTP_REMOTE_ADLOGON'];
} elseif (!empty($_SERVER['HTTP_REMOTE_GIVENNAME'])) {
    $user_id = $_SERVER['HTTP_REMOTE_GIVENNAME'];
}
$action = isset($_POST['action']) ? trim($_POST['action']) : (isset($_GET['action']) ? trim($_GET['action']) : '');
function clean_sql($value)
{
    return str_replace("'", "''", trim((string)$value));
}
function out_json($data)
{
    echo json_encode($data); exit;
}
try {

    $safe_user_id = clean_sql($user_id);
    if ($action === 'list') {
        $db = new gsr_sqlsrv_db_class();
        $sql = "SELECT fav_name, sort_order FROM GSR_ADMIN.dbo.GSR_USER_FAVORITES WHERE user_id = '{$safe_user_id}' ORDER BY sort_order, id";
        $rs = $db->run_sql_with_exit_on_error($sql);
        $items = array();
        if ($db->sqlsrv_has_rows($rs)) {
            $items = $db->fetch_array_assoc($rs);
        }
        out_json(array( 'success' => true, 'items' => $items  ));
    } elseif ($action === 'add') {
        $name = isset($_POST['name']) ? trim($_POST['name']) : '';
        if ($name === '') {
            out_json(array(
                'success' => false,
                'message' => 'Missing favorite name'
            ));
        }
        $safe_name = clean_sql($name);
        $db = new gsr_sqlsrv_db_class('gsr_write');
        $sql = "INSERT INTO GSR_ADMIN.dbo.GSR_USER_FAVORITES (user_id, fav_name, sort_order) SELECT '{$safe_user_id}', '{$safe_name}', ISNULL(MAX(F.sort_order), 0) + 1 FROM GSR_ADMIN.dbo.GSR_USER_FAVORITES F WHERE F.user_id = '{$safe_user_id}' AND NOT EXISTS (SELECT 1 FROM GSR_ADMIN.dbo.GSR_USER_FAVORITES X WHERE X.user_id = '{$safe_user_id}' AND X.fav_name = '{$safe_name}')";
        $db->run_sql_with_exit_on_error($sql);

        out_json(array(
            'success' => true,
            'message' => 'Favorite added'
        ));
    }
    elseif ($action === 'remove') {
        $name = isset($_POST['name']) ? trim($_POST['name']) : '';
        if ($name === '') {
            out_json(array( 'success' => false, 'message' => 'Missing favorite name' ));
        }
        $safe_name = clean_sql($name);
        $db = new gsr_sqlsrv_db_class('gsr_write');
        $sql = "DELETE FROM GSR_ADMIN.dbo.GSR_USER_FAVORITES WHERE user_id = '{$safe_user_id}' AND fav_name = '{$safe_name}'";
        $db->run_sql_with_exit_on_error($sql);
        out_json(array( 'success' => true, 'message' => 'Favorite removed' ));
    } else {
        out_json(array( 'success' => false, 'message' => 'Invalid action'  ));
    }

} catch (Exception $e) {

    out_json(array(
        'success' => false,
        'message' => $e->getMessage()
    ));
}
?>