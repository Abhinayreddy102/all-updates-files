<?php
declare(strict_types=1);
require_once('azure_config.php');
if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

/*
 * URL where Microsoft should redirect the user after logout.
 *
 * Replace this with your application's login/home URL.
 * It must exactly match a redirect URI configured in
 * Microsoft Entra App Registration.
 */
 $isHttps = ( (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') || (!empty($_SERVER['HTTP_X_FORWARDED_PROTO'])  && strtolower($_SERVER['HTTP_X_FORWARDED_PROTO']) === 'https'));
$protocol = $isHttps ? 'https' : 'http';
$host = $_SERVER['HTTP_HOST'];
$baseUrl = $protocol . '://' . $host . '/';
$postLogoutRedirectUri = $baseUrl . 'gsr/new/dashboard.php';
//echo $postLogoutRedirectUri; exit;
$tenantId = $azure_tenant;
/*
 * Clear all application session values, including:
 * azure_auth_FirstName
 * azure_auth_LastName
 * azure_auth_employeeType
 * azure_auth_IssueInstant
 * access_token
 * id_token
 */
$_SESSION = [];

/*
 * Remove the PHP session cookie from the browser.
 */
if (ini_get('session.use_cookies')) {
    $cookieParams = session_get_cookie_params();

    setcookie(
        session_name(),
        '',
        [
            'expires'  => time() - 42000,
            'path'     => $cookieParams['path'],
            'domain'   => $cookieParams['domain'],
            'secure'   => $cookieParams['secure'],
            'httponly' => $cookieParams['httponly'],
            'samesite' => 'Lax'
        ]
    );
}

/*
 * Destroy the server-side PHP session.
 */
session_destroy();

/*
 * Microsoft Entra logout URL.
 */
$microsoftLogoutUrl ='https://login.microsoftonline.com/' .rawurlencode($tenantId) .'/oauth2/v2.0/logout?post_logout_redirect_uri=' .rawurlencode($postLogoutRedirectUri);
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');
header('Location: ' . $microsoftLogoutUrl);
exit;