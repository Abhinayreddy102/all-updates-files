<?php
/**
 * Global Service Reports (GSR) Dashboard
 * Integrated design + existing GSR PHP menu/top reports logic.
 */
require_once 'gsr_environment.php';
require_once(GSR_DOCUMENT_ROOT . '/gsr/common/class/gsr_sqlsrv_db_class.php');


/*
 * Dashboard shared-data cache.
 *
 * This caches only data shared by all users (menus, usage rankings and Power BI data).
 * User-specific data such as Favorites and Experience Preference is intentionally NOT cached.
 */
function gsrDashboardCacheDirectory()
{
    $cache_dir = rtrim(sys_get_temp_dir(), DIRECTORY_SEPARATOR)
        . DIRECTORY_SEPARATOR . 'gsr_dashboard_cache';

    if (!is_dir($cache_dir)) {
        @mkdir($cache_dir, 0770, true);
    }

    return $cache_dir;
}

function gsrDashboardCacheFile($key)
{
    $safe_key = preg_replace('/[^A-Za-z0-9_\-]/', '_', (string)$key);
    return gsrDashboardCacheDirectory() . DIRECTORY_SEPARATOR . $safe_key . '.cache';
}

function gsrDashboardCacheGet($key, $ttl_seconds)
{
    $cache_file = gsrDashboardCacheFile($key);

    if (!is_file($cache_file) || !is_readable($cache_file)) {
        return false;
    }

    $modified_time = @filemtime($cache_file);
    if ($modified_time === false || (time() - $modified_time) > (int)$ttl_seconds) {
        @unlink($cache_file);
        return false;
    }

    $cache_contents = @file_get_contents($cache_file);
    if ($cache_contents === false || $cache_contents === '') {
        return false;
    }

    $cache_data = @unserialize($cache_contents, array('allowed_classes' => false));

    return is_array($cache_data) ? $cache_data : false;
}

function gsrDashboardCacheSet($key, array $data)
{
    $cache_file = gsrDashboardCacheFile($key);
    $temporary_file = $cache_file . '.' . getmypid() . '.tmp';
    $serialized_data = serialize($data);

    if (@file_put_contents($temporary_file, $serialized_data, LOCK_EX) === false) {
        return false;
    }

    // Atomic replace prevents another request from reading a partially-written cache file.
    if (!@rename($temporary_file, $cache_file)) {
        @unlink($temporary_file);
        return false;
    }

    return true;
}
//echo '<pre>';print_r($_SERVER);exit;
$logout_url = 'logout.php';
$display_name = $_SESSION['azure_auth_LastName'] . ', ' . $_SESSION['azure_auth_FirstName'];

$user_initial = substr(ucfirst($display_name), 0, 1);


/*
 * Switch back to Classic GSR.
 * Only this explicit action changes the saved preference back to 0.
 */
function gsrExperienceSqlValue($value)
{
    return str_replace("'", "''", (string)$value);
}


function gsrExperienceBaseUrl()
{
    $is_https =
        (!empty($_SERVER['HTTPS']) && strtolower((string)$_SERVER['HTTPS']) !== 'off')
        || (!empty($_SERVER['SERVER_PORT']) && (int)$_SERVER['SERVER_PORT'] === 443)
        || (!empty($_SERVER['HTTP_X_FORWARDED_PROTO'])
            && strtolower(trim(explode(',', (string)$_SERVER['HTTP_X_FORWARDED_PROTO'])[0])) === 'https');

    $protocol = $is_https ? 'https' : 'http';

    $host = !empty($_SERVER['HTTP_HOST'])
        ? (string)$_SERVER['HTTP_HOST']
        : (!empty($_SERVER['SERVER_NAME']) ? (string)$_SERVER['SERVER_NAME'] : 'localhost');

    // Prevent invalid characters from being used in a redirect URL.
    $host = preg_replace('/[^A-Za-z0-9.\-:\[\]]/', '', $host);

    return $protocol . '://' . $host . '/';
}

$gsr_base_url = gsrExperienceBaseUrl();
$experience_switch = isset($_GET['switch_experience']) ? strtolower((string)$_GET['switch_experience']) : '';

if ($experience_switch === 'classic') {
    $experience_user_id = '';

    if (!empty($_SERVER['HTTP_REMOTE_USER'])) {
        $experience_user_id = (string)$_SERVER['HTTP_REMOTE_USER'];
    } elseif (!empty($_SERVER['HTTP_REMOTE_ADLOGON'])) {
        $experience_user_id = (string)$_SERVER['HTTP_REMOTE_ADLOGON'];
    }

    if ($experience_user_id !== '') {
        try {
            $experience_db = new gsr_sqlsrv_db_class('gsr_write');
            $safe_user_id = gsrExperienceSqlValue($experience_user_id);
            $safe_user_name = gsrExperienceSqlValue($display_name !== '' ? $display_name : $experience_user_id);
            $clicked_url = $gsr_base_url;
            $safe_clicked_url = gsrExperienceSqlValue($clicked_url);
            /* Check whether this user already has a preference record. */
            $experience_db->run_sql_save_with_exit_on_error("SELECT id FROM [GSR_ADMIN].[dbo].[GSR_USER_EXPERIENCE_PREFERENCE] WHERE user_id = '" . $safe_user_id . "' ");
            $existing_user = $experience_db->fetch_array_assoc();
            if (!empty($existing_user)) {
                /* Existing user: update the same record. */
                $experience_db->run_sql_save_with_exit_on_error("UPDATE [GSR_ADMIN].[dbo].[GSR_USER_EXPERIENCE_PREFERENCE] SET user_name = '" . $safe_user_name . "', clicked_datetime = GETDATE(), clicked_url = '" . $safe_clicked_url . "', clicked_status = 0 WHERE user_id = '" . $safe_user_id . "'");
            } else {
                /* New user: create the preference record once. */
                $experience_db->run_sql_save_with_exit_on_error("INSERT INTO [GSR_ADMIN].[dbo].[GSR_USER_EXPERIENCE_PREFERENCE] (user_id, user_name, clicked_datetime, clicked_url, clicked_status) VALUES ('" . $safe_user_id . "', '" . $safe_user_name . "', GETDATE(), '" . $safe_clicked_url . "', 0)");
            }
            unset($experience_db);
        } catch (Exception $e) {
            /* Switching UI must still work even if preference logging fails. */
        }
    }

    header('Location: ' . $gsr_base_url);
    exit;
}


/*
 * Shared dashboard cache settings.
 * 300 seconds (5 minutes) keeps the dashboard fresh while avoiding repeated heavy SQL calls.
 * Change this value if a shorter/longer refresh interval is required.
 */
$dashboard_cache_ttl = 300;
$dashboard_cache_key = 'shared_v5_' . strtolower((string)SERVER_ENVIRONMENT) . '_' . date('Ym');
$dashboard_cached_data = gsrDashboardCacheGet($dashboard_cache_key, $dashboard_cache_ttl);
$dashboard_cache_hit = is_array($dashboard_cached_data);

/*
 * Sidebar group icons.
 * Group titles still come from GSR_ADMIN_GUI_MENUS.
 * Keep this outside the cache HIT/MISS block so icons work in both cases.
 */
$menu_icon_map = array(
    'Instrument - Centric' => 'settings',
    'Customer & CSS Information' => 'groups',
    'Customer & CSS Info' => 'groups',
    'Remote Support' => 'support_agent',
    'Assay' => 'science',
    'Abbottlink' => 'link',
    'Global Service Tools' => 'build',
    'Installation &amp; Parts Data' => 'inventory_2',
    'Installation & Parts Data' => 'inventory_2',
    'Search Tools' => 'search',
    'Secondary Reports' => 'article',
    'Development Items' => 'code',
    'Reference Items' => 'menu_book',
    'PowerBI Clearinghouse' => 'analytics'
);

if ($dashboard_cache_hit) {
    $menu_data = $dashboard_cached_data['menu_data'] ?? array();
    $report_menu_lookup = $dashboard_cached_data['report_menu_lookup'] ?? array();
    $complete_report_menu_lookup = $dashboard_cached_data['complete_report_menu_lookup'] ?? array();
    $top_reports = $dashboard_cached_data['top_reports'] ?? array();
    $report_usage_counts = $dashboard_cached_data['report_usage_counts'] ?? array();
    $active_report_titles = $dashboard_cached_data['active_report_titles'] ?? array();
    $active_usage_names = $dashboard_cached_data['active_usage_names'] ?? array();
    $active_report_count = (int)($dashboard_cached_data['active_report_count'] ?? 0);
    $usage_data_loaded = !empty($dashboard_cached_data['usage_data_loaded']);
    $usage_period_label = $dashboard_cached_data['usage_period_label'] ?? '';
    $development_report_titles = $dashboard_cached_data['development_report_titles'] ?? array();
    $powerbi_dashboard_groups = $dashboard_cached_data['powerbi_dashboard_groups'] ?? array();
    $powerbi_report_count = (int)($dashboard_cached_data['powerbi_report_count'] ?? 0);
    $usage_min_period = (int)($dashboard_cached_data['usage_min_period'] ?? 0);
    $usage_max_period = (int)($dashboard_cached_data['usage_max_period'] ?? 0);
    $current_month_unique_users = (int)($dashboard_cached_data['current_month_unique_users'] ?? 0);
    $current_month_login_user_count = (int)($dashboard_cached_data['current_month_login_user_count'] ?? 0);
    $reference_report_count = (int)($dashboard_cached_data['reference_report_count'] ?? 0);
    $normal_sidebar_report_limit = max(0, 58 - $reference_report_count);
    $filter_sidebar_by_usage = true;
    $sidebar_report_limit = 58;
} else {
/*
 * Dashboard menu configuration.
 * Normal sidebar reports are limited to the top 58 usage-based reports.
 * Reference Items and PowerBI Clearinghouse are handled separately.
 */
$menu_data = array();
$report_menu_lookup = array();
$complete_report_menu_lookup = array();
$top_reports = array();
$report_usage_counts = array();
$active_report_titles = array();
$active_usage_names = array();
$active_report_count = 0;
$usage_data_loaded = false;
$usage_period_label = '';
$development_report_titles = array();

$filter_sidebar_by_usage = true;
$sidebar_report_limit = 58;

try {
    $menu_db = new sqlsrv_db_class();

    switch (SERVER_ENVIRONMENT) {
        case 'DEV':
            $environment_filter = 'dev_active = 1';
            $environment_link_column = 'dev_link AS link';
            break;
        case 'TEST':
            $environment_filter = 'test_active = 1';
            $environment_link_column = 'test_link AS link';
            break;
        case 'QA':
            $environment_filter = 'qa_active = 1';
            $environment_link_column = 'qa_link AS link';
            break;
        case 'PROD':
        default:
            $environment_filter = 'prod_active = 1';
            $environment_link_column = 'prod_link AS link';
            break;
    }

    /* Load the complete active menu first. usage filtering is applied after
       the usage query succeeds, which prevents a usage-query failure from
       breaking the existing navigation. */
    $menu_db->run_sql_save_with_exit_on_error("SELECT
        COALESCE(slide_out_side, CAST([L1] AS varchar)) AS L1,
        COALESCE(slide_out_order, [L2]) AS L2,
        [web_app_icon],
        [title],
        [validation_icon],
        [validated_for_prod],
        " . $environment_link_column . ",
        [target],
        [description],
        [submit_request],
        slide_out_side,
        slide_out_order
        FROM [GSR_ADMIN].[dbo].[GSR_ADMIN_GUI_MENUS]
        WHERE " . $environment_filter . "
        ORDER BY
            CASE WHEN slide_out_side IS NULL THEN 0 ELSE 1 END,
            TRY_CONVERT(int, [L1]),
            [L1],
            [L2],
            slide_out_side,
            slide_out_order");

    $menu_rows = $menu_db->fetch_array_assoc();

    foreach ($menu_rows as $item) {
        $l1 = (string)($item['L1'] ?? '');
        $l2 = (int)($item['L2'] ?? 0);

        if ($l1 === '') {
            continue;
        }

        if ($l1 === '0' && $l2 === 0) {
            $menu_data['main_title'] = $item['title'] ?? 'Global Service Reports';
            continue;
        }

        if (!isset($menu_data['items'][$l1])) {
            $menu_data['items'][$l1] = array(
                'title' => 'Reports',
                'icon'  => 'folder',
                'items' => array()
            );
        }

        if ($l2 === 0) {
            $menu_data['items'][$l1]['title'] = $item['title'] ?? 'Reports';
            $menu_data['items'][$l1]['icon']  = $item['web_app_icon'] ?? 'folder';
            continue;
        }

        $menu_data['items'][$l1]['items'][] = array(
            'original_l2' => $l2,
            'title' => $item['title'] ?? '',
            'link'  => $item['link'] ?? '#',
            'target' => $item['target'] ?? '_blank',
            'desc'  => $item['description'] ?? '',
            'icon'  => $item['web_app_icon'] ?? 'description',
            'validation_icon' => $item['validation_icon'] ?? '',
            'validated_for_prod' => $item['validated_for_prod'] ?? 'N',
            'kount' => 0
        );
    }

    unset($menu_db);
} catch (Exception $e) {
    $menu_data = array();
}

/* Build a complete menu lookup before sidebar usage filtering.
 * removed just because the sidebar applies additional usage rules.
 */
if (!empty($menu_data['items'])) {
    foreach ($menu_data['items'] as $group) {
        if (empty($group['items'])) {
            continue;
        }

        foreach ($group['items'] as $item) {
            $title = (string)($item['title'] ?? '');
            if ($title === '') {
                continue;
            }

            $complete_report_menu_lookup[strtolower($title)] = array(
                'title' => $title,
                'link' => $item['link'] ?? '#',
                'desc' => $item['desc'] ?? '',
                'validated_for_prod' => $item['validated_for_prod'] ?? 'N'
            );
        }
    }
}

/* Build a title lookup for Development Items so those reports can be excluded*/
if (!empty($menu_data['items'])) {
    foreach ($menu_data['items'] as $menu_group) {
        if (strtolower((string)($menu_group['title'] ?? '')) !== 'development items') {
            continue;
        }

        foreach (($menu_group['items'] ?? array()) as $development_item) {
            $development_title = strtolower((string)($development_item['title'] ?? ''));
            if ($development_title !== '') {
                $development_report_titles[$development_title] = true;
            }
        }
    }
}

/* Build the active GSR menu population. Reference Items are displayed in the
 * same left sidebar and count toward the requested total of 58 GSR reports.
 * Development Items are excluded; Power BI is counted separately.
 */
$eligible_sidebar_menu_reports = array();
$reference_report_count = 0;
if (!empty($menu_data['items'])) {
    foreach ($menu_data['items'] as $menu_group) {
        $group_title_key = strtolower(trim((string)($menu_group['title'] ?? '')));

        if ($group_title_key === 'development items') {
            continue;
        }

        /* Reference Items are displayed in the same GSR sidebar and therefore
         * count toward the 58 visible GSR reports requested for the dashboard.
         */
        if ($group_title_key === 'reference items') {
            $reference_report_count += count($menu_group['items'] ?? array());
            continue;
        }

        foreach (($menu_group['items'] ?? array()) as $menu_item) {
            $menu_title = trim((string)($menu_item['title'] ?? ''));
            if ($menu_title === '') {
                continue;
            }

            $menu_key = strtolower($menu_title);
            if (!isset($eligible_sidebar_menu_reports[$menu_key])) {
                $eligible_sidebar_menu_reports[$menu_key] = $menu_title;
            }
        }
    }
}

/* The Active Reports card represents the total visible GSR report population.
 * Reference Items remain visible, so reserve their slots inside the total 58.
 */
$normal_sidebar_report_limit = max(0, $sidebar_report_limit - $reference_report_count);

$powerbi_dashboard_groups = array();

try {
    $powerbi_db = new sqlsrv_db_class();

    switch (SERVER_ENVIRONMENT) {
        case 'DEV':
            $powerbi_environment_filter = 'dev_active = 1';
            break;
        case 'TEST':
            $powerbi_environment_filter = 'test_active = 1';
            break;
        case 'QA':
            $powerbi_environment_filter = 'qa_active = 1';
            break;
        case 'PROD':
        default:
            $powerbi_environment_filter = 'prod_active = 1';
            break;
    }

    $powerbi_db->run_sql_save_with_exit_on_error("SELECT
        COALESCE(slide_out_side, CAST([L1] AS varchar)) AS L1,
        COALESCE(slide_out_order, [L2]) AS L2,
        [title],
        [link],
        [description],
        slide_out_side
        FROM [GSR_ADMIN].[dbo].[PBI_ADMIN_GUI_MENUS]
        WHERE " . $powerbi_environment_filter . "
        ORDER BY slide_out_side, slide_out_order, [L1], [L2]");

    $powerbi_rows = $powerbi_db->fetch_array_assoc();
    $powerbi_group_titles = array();

    foreach ($powerbi_rows as $powerbi_item) {
        $powerbi_level_one = (string)($powerbi_item['L1'] ?? '');
        $powerbi_level_two = (int)($powerbi_item['L2'] ?? 0);

        if (!empty($powerbi_item['slide_out_side'])) {
            continue;
        }

        if ($powerbi_level_one === '0' && $powerbi_level_two === 0) {
            continue;
        }

        if ($powerbi_level_two === 0) {
            $powerbi_group_titles[$powerbi_level_one] = $powerbi_item['title'];
            if (!isset($powerbi_dashboard_groups[$powerbi_level_one])) {
                $powerbi_dashboard_groups[$powerbi_level_one] = array('title' => $powerbi_item['title'], 'items' => array());
            } else {
                $powerbi_dashboard_groups[$powerbi_level_one]['title'] = $powerbi_item['title'];
            }
            continue;
        }

        if (!isset($powerbi_dashboard_groups[$powerbi_level_one])) {
            $powerbi_dashboard_groups[$powerbi_level_one] = array(
                'title' => $powerbi_group_titles[$powerbi_level_one] ?? 'Power BI Reports',
                'items' => array()
            );
        }

        $powerbi_dashboard_groups[$powerbi_level_one]['items'][] = array(
            'title' => $powerbi_item['title'] ?? '',
            'link'  => $powerbi_item['link'] ?? '#',
            'desc'  => $powerbi_item['description'] ?? ''
        );
    }

    unset($powerbi_db);
} catch (Exception $e) {
    $powerbi_dashboard_groups = array();
}
$powerbi_report_count = 0;

foreach ($powerbi_dashboard_groups as $group) {
    $powerbi_report_count += count($group['items']);
}
/*
 * Dynamic report-population period: the last three COMPLETED calendar months.
 * Example: during July 2026, the range is April 2026 through June 2026
 * (202604 through 202606). No hard-coded validation period is used.
 */
$current_month_start = new DateTime('first day of this month 00:00:00');
$usage_start_date = clone $current_month_start;
$usage_end_date = clone $current_month_start;
$usage_start_date->modify('-3 months');
$usage_end_date->modify('-1 month');

$usage_min_period = (int)$usage_start_date->format('Ym');
$usage_max_period = (int)$usage_end_date->format('Ym');
$usage_period_label = $usage_start_date->format('M Y') . ' - ' . $usage_end_date->format('M Y');

try {
    $usage_db = new gsr_sqlsrv_db_class('gsr_read_prod');

    /*
     * Read the live rollup-table schema first. usage requirements shows filters such as
     * ft_type and division, but those columns are not present in every deployed
     * version of GSR_USE_LOGS_ROLLUP. Building the WHERE clause from the columns
     * that actually exist prevents the dashboard from failing with SQL 207.
     */
    $rollup_columns = array();
    $schema_query = "
        SELECT LOWER(COLUMN_NAME) AS column_name
        FROM GSR.INFORMATION_SCHEMA.COLUMNS
        WHERE TABLE_SCHEMA = 'dbo'
          AND TABLE_NAME = 'GSR_USE_LOGS_ROLLUP'";

    $schema_result = $usage_db->run_sql_with_exit_on_error($schema_query);

    if ($usage_db->sqlsrv_has_rows($schema_result)) {
        $schema_rows = $usage_db->fetch_array_assoc($schema_result);

        foreach ($schema_rows as $schema_row) {
            $column_name = strtolower((string)($schema_row['column_name'] ?? ''));
            if ($column_name !== '') {
                $rollup_columns[$column_name] = true;
            }
        }
    }

    $required_rollup_columns = array(
        'period',
        'gsr_report_level_1',
        'gsr_report_level_2',
        'adlogon',
        'kount'
    );

    foreach ($required_rollup_columns as $required_column) {
        if (empty($rollup_columns[$required_column])) {
            throw new Exception(
                'Missing required GSR_USE_LOGS_ROLLUP column: ' . $required_column
            );
        }
    }

    $usage_filters = array(
        "period BETWEEN {$usage_min_period} AND {$usage_max_period}",
        "UPPER(LTRIM(RTRIM(ISNULL(gsr_report_level_1, '')))) NOT IN ('GSR HOME', 'HELP')",
        "NULLIF(LTRIM(RTRIM(ISNULL(gsr_report_level_2, ''))), '') IS NULL",
        "UPPER(LTRIM(RTRIM(ISNULL(adlogon, '')))) <> 'LONGYX2'",
        "NULLIF(LTRIM(RTRIM(ISNULL(gsr_report_level_1, ''))), '') IS NOT NULL"
    );

    /* Apply additional usage filters only when the live rollup table exposes them. */
    if (!empty($rollup_columns['ft_type'])) {
        $usage_filters[] = "UPPER(LTRIM(RTRIM(ISNULL(ft_type, '')))) IN ('AMB', 'MGR', 'TSO', 'FSE')";
    }

    if (!empty($rollup_columns['division'])) {
        $usage_filters[] = "(division IS NULL OR UPPER(LTRIM(RTRIM(division))) NOT IN ('AMD', 'ATM', 'ADI'))";
    }

    if (!empty($rollup_columns['allow_deny'])) {
        $usage_filters[] = "UPPER(LTRIM(RTRIM(ISNULL(allow_deny, '')))) = 'ALLOW'";
    }

    $sql = "
        SELECT
            LTRIM(RTRIM(gsr_report_level_1)) AS report,
            SUM(ISNULL(kount, 0)) AS kount,
            COUNT(DISTINCT LTRIM(RTRIM(adlogon))) AS user_count
        FROM GSR.dbo.GSR_USE_LOGS_ROLLUP
        WHERE " . implode("
          AND ", $usage_filters) . "
        GROUP BY LTRIM(RTRIM(gsr_report_level_1))
        ORDER BY SUM(ISNULL(kount, 0)) DESC,
                 LTRIM(RTRIM(gsr_report_level_1)) ASC";

    $rs = $usage_db->run_sql_with_exit_on_error($sql);

    if ($usage_db->sqlsrv_has_rows($rs)) {
        $usage_rows = $usage_db->fetch_array_assoc($rs);
        $all_report_usage_counts = array();
        $all_usage_names = array();

        /* Build usage lookup directly from database report names. */
        foreach ($usage_rows as $row) {
            $usage_report_name = (string)($row['report'] ?? '');

            if ($usage_report_name === '') {
                continue;
            }

            $usage_key = strtolower($usage_report_name);
            $usage_count = (int)($row['kount'] ?? 0);

            if ($usage_key === '' || !empty($development_report_titles[$usage_key])) {
                continue;
            }

            if (!isset($all_report_usage_counts[$usage_key])) {
                $all_report_usage_counts[$usage_key] = 0;
                $all_usage_names[$usage_key] = $usage_report_name;
            }

            $all_report_usage_counts[$usage_key] += $usage_count;
        }

        /*
         * Build the actual 58 REPORTS THAT CAN BE DISPLAYED IN THE GUI.
         *
         * Previously the code took the first 58 usage-log names and only later
         * compared them with GSR_ADMIN_GUI_MENUS. Usage names that did not match
         * a current GUI title were then removed, which is why the card could say
         * 58 while the sidebar showed far fewer reports.
        */
        arsort($all_report_usage_counts, SORT_NUMERIC);

        $report_usage_counts = array();
        $active_usage_names = array();

        /* First priority: reports with a direct usage-name -> GUI-title match. */
        foreach ($all_report_usage_counts as $usage_key => $usage_count) {
            if (count($report_usage_counts) >= $normal_sidebar_report_limit) {
                break;
            }

            if (!isset($eligible_sidebar_menu_reports[$usage_key])) {
                continue;
            }

            $report_usage_counts[$usage_key] = (int)$usage_count;
            $active_usage_names[] = $eligible_sidebar_menu_reports[$usage_key];
        }

        /*
         * Fill any remaining slots from active menu reports.
         * This does not invent reports: every fallback item is an active report from
         * GSR_ADMIN_GUI_MENUS. A zero kount only means its usage-log name did not
         * exactly match the current GUI title in this query result.
         */
        if (count($report_usage_counts) < $normal_sidebar_report_limit) {
            foreach ($eligible_sidebar_menu_reports as $menu_key => $menu_title) {
                if (count($report_usage_counts) >= $normal_sidebar_report_limit) {
                    break;
                }

                if (isset($report_usage_counts[$menu_key])) {
                    continue;
                }

                $report_usage_counts[$menu_key] = isset($all_report_usage_counts[$menu_key])
                    ? (int)$all_report_usage_counts[$menu_key]
                    : 0;
                $active_usage_names[] = $menu_title;
            }
        }

        $active_report_titles = array_fill_keys(array_keys($report_usage_counts), true);
        $active_report_count = count($report_usage_counts) + $reference_report_count;
        $usage_data_loaded = ($active_report_count > 0);
    }

    unset($usage_db);
} catch (Exception $e) {
    $report_usage_counts = array();
    $active_report_titles = array();
    $active_usage_names = array();
    $active_report_count = 0;
    $usage_data_loaded = false;
}

/*
 * Limit normal dashboard report groups to the reports returned by filter logic
 * usage logic. Reference Items remain available and are not counted.
 * Development Items also remain available and are positioned immediately
 * above Reference Items. If the usage query fails, the full menu is retained.
 */
if ($filter_sidebar_by_usage && $usage_data_loaded && !empty($menu_data['items'])) {
    foreach ($menu_data['items'] as $group_key => &$menu_group) {
        $group_title = (string)($menu_group['title'] ?? '');
        /* Development Items are intentionally hidden everywhere. */
        if (strtolower($group_title) === 'development items') {
            unset($menu_data['items'][$group_key]);
            continue;
        }

        $keep_entire_group = (strtolower($group_title) === 'reference items');

        if (!$keep_entire_group && !empty($menu_group['items'])) {
            $menu_group['items'] = array_values(array_filter(
                $menu_group['items'],
                function ($item) use ($active_report_titles) {
                    $title_key = strtolower((string)($item['title'] ?? ''));
                    return !empty($active_report_titles[$title_key]);
                }
            ));
        }

        if (empty($menu_group['items'])) {
            unset($menu_data['items'][$group_key]);
        }
    }
    unset($menu_group);
}

/*
 * Apply usage-filtered usage counts to the reports that remain in the sidebar.
 */
if (!empty($menu_data['items'])) {
    foreach ($menu_data['items'] as $group_key => &$menu_group) {
        $menu_group['original_l1'] = $group_key;
        $menu_group['group_max_kount'] = 0;
        $menu_group['group_total_kount'] = 0;

        if (empty($menu_group['items'])) {
            continue;
        }

        foreach ($menu_group['items'] as &$item) {
            $title = (string)($item['title'] ?? '');
            $usage_key = strtolower($title);
            $item['kount'] = isset($report_usage_counts[$usage_key])
                ? (int)$report_usage_counts[$usage_key]
                : 0;

            $menu_group['group_max_kount'] = max(
                (int)$menu_group['group_max_kount'],
                (int)$item['kount']
            );
            $menu_group['group_total_kount'] += (int)$item['kount'];
        }
        unset($item);

        /* Highest-used child report first; original L2 is the tie-breaker. */
        usort($menu_group['items'], function ($a, $b) {
            $a_kount = (int)($a['kount'] ?? 0);
            $b_kount = (int)($b['kount'] ?? 0);

            if ($a_kount !== $b_kount) {
                return $b_kount <=> $a_kount;
            }

            $a_l2 = (int)($a['original_l2'] ?? 0);
            $b_l2 = (int)($b['original_l2'] ?? 0);

            if ($a_l2 !== $b_l2) {
                return $a_l2 <=> $b_l2;
            }

            return strcmp(
                strtolower((string)($a['title'] ?? '')),
                strtolower((string)($b['title'] ?? ''))
            );
        });
    }
    unset($menu_group);

    /*
     * Parent group containing the highest-used child appears first.
     * Total group usage and original L1 are used as tie-breakers.
     */
    uasort($menu_data['items'], function ($a, $b) {
        /* Always keep Reference Items last. PowerBI is rendered after it. */
        $special_order = array(
            'Reference Items' => 1
        );

        $a_special = $special_order[(string)($a['title'] ?? '')] ?? 0;
        $b_special = $special_order[(string)($b['title'] ?? '')] ?? 0;

        if ($a_special !== $b_special) {
            return $a_special <=> $b_special;
        }

        $a_max = (int)($a['group_max_kount'] ?? 0);
        $b_max = (int)($b['group_max_kount'] ?? 0);

        if ($a_max !== $b_max) {
            return $b_max <=> $a_max;
        }

        $a_total = (int)($a['group_total_kount'] ?? 0);
        $b_total = (int)($b['group_total_kount'] ?? 0);

        if ($a_total !== $b_total) {
            return $b_total <=> $a_total;
        }

        $a_l1 = $a['original_l1'] ?? '';
        $b_l1 = $b['original_l1'] ?? '';

        if (is_numeric($a_l1) && is_numeric($b_l1)) {
            return (int)$a_l1 <=> (int)$b_l1;
        }

        return strnatcasecmp((string)$a_l1, (string)$b_l1);
    });
}

if (!empty($menu_data['items'])) {
    foreach ($menu_data['items'] as $group) {
        if (empty($group['items'])) {
            continue;
        }

        foreach ($group['items'] as $item) {
            $title = (string)($item['title'] ?? '');

            if ($title === '') {
                continue;
            }

            $report_menu_lookup[strtolower($title)] = array(
                'title' => $title,
                'link' => $item['link'] ?? '#',
                'desc' => $item['desc'] ?? '',
                'validated_for_prod' => $item['validated_for_prod'] ?? 'N'
            );
        }
    }
}

/* Build Top 15 using the same ranking logic as the validation SQL:
 *   gsr_report_level_2 IS NULL
 *   period BETWEEN last 3 completed months
 *   gsr_report_level_1 <> 'GSR HOME'
 * No sidebar-specific filters are applied here.
 */
try {
    $top_reports_db = new gsr_sqlsrv_db_class('gsr_read_prod');

    $top_reports_query = "
        SELECT TOP 15
            LTRIM(RTRIM(gsr_report_level_1)) AS report,
            SUM(kount) AS kount
        FROM GSR.dbo.GSR_USE_LOGS_ROLLUP
        WHERE gsr_report_level_2 IS NULL
          AND period BETWEEN {$usage_min_period} AND {$usage_max_period}
          AND gsr_report_level_1 <> 'GSR HOME'
        GROUP BY gsr_report_level_1
        ORDER BY SUM(kount) DESC";

    $top_reports_result = $top_reports_db->run_sql_with_exit_on_error($top_reports_query);

    if ($top_reports_db->sqlsrv_has_rows($top_reports_result)) {
        $top_report_rows = $top_reports_db->fetch_array_assoc($top_reports_result);

        foreach ($top_report_rows as $row) {
            $source_report_name = (string)($row['report'] ?? '');
            if ($source_report_name === '') {
                continue;
            }

            // Keep the exact report name returned by GSR_USE_LOGS_ROLLUP.
            // Menu metadata is attached only when the same title exists in GSR_ADMIN_GUI_MENUS.
            $lookup_key = strtolower($source_report_name);
            $menu_meta = $complete_report_menu_lookup[$lookup_key] ?? array();

            $top_reports[] = array(
                'title' => $source_report_name,
                'link' => $menu_meta['link'] ?? '#',
                'desc' => $menu_meta['desc'] ?? '',
                'validated_for_prod' => $menu_meta['validated_for_prod'] ?? 'N',
                'source_report' => $source_report_name,
                'kount' => (int)($row['kount'] ?? 0)
            );
        }
    }

    unset($top_reports_db);
} catch (Exception $e) {
    $top_reports = array();
}


    /*
     * Shared KPI counts are also cached. These values are the same for every user,
     * so running the aggregation queries on every dashboard request only adds latency.
     */
    $current_month_unique_users = 0;
    $current_month_login_user_count = 0;

    try {
        $kpi_db = new gsr_sqlsrv_db_class('gsr_read_prod');
        $current_period = (int)date('Ym');

        $kpi_sql = "
            SELECT COUNT(DISTINCT LTRIM(RTRIM(adlogon))) AS active_user_count
            FROM GSR.dbo.GSR_USE_LOGS_ROLLUP
            WHERE period = {$current_period}
              AND adlogon IS NOT NULL
              AND LTRIM(RTRIM(adlogon)) <> ''";

        $kpi_rs = $kpi_db->run_sql_with_exit_on_error($kpi_sql);
        if ($kpi_db->sqlsrv_has_rows($kpi_rs)) {
            $kpi_rows = $kpi_db->fetch_array_assoc($kpi_rs);
            $current_month_unique_users = (int)($kpi_rows[0]['active_user_count'] ?? 0);
        }

        /*
         * Range predicate keeps date_time searchable by an index.
         * YEAR(date_time)/MONTH(date_time) on the column can force a much larger scan.
         */
        $month_start = date('Y-m-01 00:00:00');
        $next_month_start = date('Y-m-01 00:00:00', strtotime('first day of next month'));

        $login_sql = "
            SELECT COUNT(DISTINCT LTRIM(RTRIM(adlogon))) AS login_user_count
            FROM GSR.dbo.GSR_USE_LOGS
            WHERE date_time >= '{$month_start}'
              AND date_time < '{$next_month_start}'
              AND adlogon IS NOT NULL
              AND LTRIM(RTRIM(adlogon)) <> ''";

        $login_rs = $kpi_db->run_sql_with_exit_on_error($login_sql);
        if ($kpi_db->sqlsrv_has_rows($login_rs)) {
            $login_rows = $kpi_db->fetch_array_assoc($login_rs);
            $current_month_login_user_count = (int)($login_rows[0]['login_user_count'] ?? 0);
        }

        unset($kpi_db);
    } catch (Exception $e) {
        $current_month_unique_users = 0;
        $current_month_login_user_count = 0;
    }

    gsrDashboardCacheSet($dashboard_cache_key, array(
        'menu_data' => $menu_data,
        'report_menu_lookup' => $report_menu_lookup,
        'complete_report_menu_lookup' => $complete_report_menu_lookup,
        'top_reports' => $top_reports,
        'report_usage_counts' => $report_usage_counts,
        'active_report_titles' => $active_report_titles,
        'active_usage_names' => $active_usage_names,
        'active_report_count' => $active_report_count,
        'usage_data_loaded' => $usage_data_loaded,
        'usage_period_label' => $usage_period_label,
        'development_report_titles' => $development_report_titles,
        'powerbi_dashboard_groups' => $powerbi_dashboard_groups,
        'powerbi_report_count' => $powerbi_report_count,
        'usage_min_period' => $usage_min_period,
        'usage_max_period' => $usage_max_period,
        'current_month_unique_users' => $current_month_unique_users,
        'current_month_login_user_count' => $current_month_login_user_count,
        'reference_report_count' => $reference_report_count
    ));
}

// Helpful during testing: browser dev tools can confirm HIT/MISS without changing the page UI.
if (!headers_sent()) {
    header('X-GSR-Dashboard-Cache: ' . ($dashboard_cache_hit ? 'HIT' : 'MISS'));
}

function renderMenuIcon($icon, $fallback = 'folder')
{
    $icon = (string)$icon;

    if ($icon !== '' && stripos($icon, '<img') !== false) {
        return $icon;
    }

    if ($icon !== '') {
        return '<span class="material-icons-outlined">' . htmlspecialchars((string)$icon, ENT_QUOTES, 'UTF-8') . '</span>';
    }

    return '<span class="material-icons-outlined">' . htmlspecialchars((string)$fallback, ENT_QUOTES, 'UTF-8') . '</span>';
}
$search_items = array();

/*
 * Global search uses the COMPLETE active GSR menu that was loaded before
 * Top-58 sidebar filter was applied. This changes SEARCH ONLY.
 * The sidebar, Active Reports count, usage logic, favorites, Power BI,
 * KPI cards and cache population are left unchanged.
 */
if (!empty($complete_report_menu_lookup)) {
    foreach ($complete_report_menu_lookup as $menu_meta) {
        $search_title = (string)($menu_meta['title'] ?? '');
        $search_desc = (string)($menu_meta['desc'] ?? '');

        if ($search_title === '') {
            continue;
        }

        /* Keep Development Items out of the dashboard search. */
        $title_key = strtolower($search_title);
        if (!empty($development_report_titles[$title_key])) {
            continue;
        }

        $search_items[] = array(
            'type' => 'Reports',
            'title' => $search_title,
            'desc' => $search_desc,
            'link' => $menu_meta['link'] ?? '#',
            'icon' => 'description',
            'validated_for_prod' => $menu_meta['validated_for_prod'] ?? 'N'
        );
    }
}

/*
 * Add Power BI Clearinghouse reports to header search only.
 * This does not change Power BI rendering, access rules, counts, cache data or sidebar behavior.
 */
if (!empty($powerbi_dashboard_groups)) {
    foreach ($powerbi_dashboard_groups as $powerbi_group) {
        foreach (($powerbi_group['items'] ?? array()) as $powerbi_item) {
            $powerbi_title = trim((string)($powerbi_item['title'] ?? ''));

            if ($powerbi_title === '') {
                continue;
            }

            $search_items[] = array(
                'type' => 'Power BI Reports',
                'title' => $powerbi_title,
                'desc' => (string)($powerbi_item['desc'] ?? ''),
                'link' => $powerbi_item['link'] ?? '#',
                'icon' => 'analytics',
                'validated_for_prod' => 'N',
                'favorite_enabled' => false,
                'keywords' => 'powerbi power bi power bi reports powerbi clearinghouse'
            );
        }
    }
}
$user_favorites = array();
/*
 * Favorites are user-specific, so do not block the initial dashboard render with
 * another database round trip. gsr_favorites_ajax.php loads them immediately
 * after DOMContentLoaded and synchronizes all star states.
 */
?>

<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="robots" content="noindex, nofollow, noimageindex">
<meta http-equiv="X-UA-Compatible" content="IE=edge, chrome=1" />
<title>Global Service Reports (GSR)</title>
<link href="https://fonts.googleapis.com/icon?family=Material+Icons+Outlined" rel="stylesheet">
<style>

:root{
  --abbott-blue:#009CDE;
  --abbott-dark-blue:#003087;
  --abbott-navy:#0A1628;
  --abbott-indigo:#000075;
  --abbott-periwinkle:#97A3F5;
  --abbott-bright:#2E4AED;
  --abbott-teal:#004F71;
  --surface-primary:#F0F4F8;
  --surface-card:#FFFFFF;
  --surface-card-hover:#F7FAFF;
  --accent-green:#059669;
  --accent-amber:#D97706;
  --accent-red:#DC2626;
  --accent-purple:#7C3AED;
  --text-primary:#1E293B;
  --text-secondary:#475569;
  --text-tertiary:#94A3B8;
  --sidebar-width:300px;
  --header-height:64px;
  --radius-sm:8px;
  --radius-md:12px;
  --radius-lg:16px;
  --radius-xl:20px;
  --transition-fast:150ms cubic-bezier(.4,0,.2,1);
  --transition-smooth:300ms cubic-bezier(.4,0,.2,1);
  --shadow-card:0 1px 3px rgba(0,0,0,.06),0 4px 16px rgba(0,0,0,.06);
  --shadow-elevated:0 8px 28px rgba(15,23,42,.16);
}
*,*::before,*::after{margin:0;padding:0;box-sizing:border-box}
html{font-size:16px;-webkit-font-smoothing:antialiased}
body{font-family:system-ui,-apple-system,"Segoe UI",Roboto,"Helvetica Neue","Noto Sans","Liberation Sans",Arial,sans-serif;background:var(--surface-primary);color:var(--text-primary);min-height:100vh;overflow-x:hidden}
a{text-decoration:none;color:inherit}
button{font-family:inherit;cursor:pointer;border:0;background:none}
.app{display:flex;min-height:100vh;width:100%}

/* Sidebar */
.side{width:var(--sidebar-width);background:#000060;display:flex;flex-direction:column;position:fixed;top:0;left:0;bottom:0;z-index:200;transition:transform var(--transition-smooth);box-shadow:0 18px 40px rgba(0,0,0,.12)}
.side-hdr{padding:24px 20px;border-bottom:1px solid rgba(255,255,255,.1);display:flex;flex-direction:column;gap:10px}
.abbott-logo{color:#fff;display:block}.abbott-logo svg{height:30px;width:auto}.side-product{font-size:18px;font-weight:600;color:rgba(255,255,255,.9);letter-spacing:.2px}
.side-nav{flex:1;overflow-y:auto;padding:8px 0;scrollbar-width:thin;scrollbar-color:rgba(255,255,255,.18) transparent}
.nav-grp-label{padding:20px 20px 6px;font-size:10px;font-weight:700;letter-spacing:2px;text-transform:uppercase;color:#fff}
.nav-item{display:flex;align-items:center;gap:10px;padding:10px 20px;font-size:15px;font-weight:500;color:#fff;cursor:pointer;transition:all var(--transition-fast);border-left:3px solid transparent;width:100%;text-align:left}
.nav-item:hover{color:rgba(255,255,255,.78);background:rgba(255,255,255,.08)}.nav-item.active{color:#fff;background:rgba(151,163,245,.18);border-left-color:var(--abbott-periwinkle);font-weight:600}.nav-item .material-icons-outlined{font-size:19px;opacity:.75}.nav-chev{margin-left:auto;font-size:16px!important;opacity:.5!important;transition:transform var(--transition-fast)}.nav-item.expanded .nav-chev{transform:rotate(90deg)}
.nav-subs{max-height:0;overflow:hidden;transition:max-height var(--transition-smooth)}.nav-item.expanded+.nav-subs{max-height:900px}.nav-sub{display:flex;align-items:center;gap:8px;padding:7px 20px 7px 38px;font-size:14px;color:rgba(255,255,255,.58);cursor:pointer;transition:all var(--transition-fast)}.nav-sub:hover{color:#fff;background:rgba(255,255,255,.06)}.nav-sub-icon{font-size:16px!important;opacity:.65}
.side-ft{padding:14px 20px;border-top:1px solid rgba(255,255,255,.1);display:flex;align-items:center;gap:10px}.u-circle{width:32px;height:32px;border-radius:50%;background:var(--abbott-periwinkle);display:flex;align-items:center;justify-content:center;font-size:13px;font-weight:700;color:var(--abbott-indigo);flex-shrink:0}.u-name{font-size:13px;font-weight:600;color:#fff}.u-role{font-size:11px;color:rgba(255,255,255,.45)}

/* Main and header */
.main{flex:1;margin-left:var(--sidebar-width);display:flex;flex-direction:column;min-height:100vh;min-width:0}.top-bar{height:var(--header-height);background:#fff;border-bottom:1px solid rgba(0,0,0,.06);display:flex;align-items:center;padding:0 32px;gap:16px;position:sticky;top:0;z-index:120}.hamburger{display:none;color:var(--text-secondary);width:38px;height:38px;border-radius:50%;align-items:center;justify-content:center}.hamburger:hover{background:rgba(0,0,0,.06)}.topbar-title{font-size:36px;font-weight:600;color:var(--abbott-indigo);letter-spacing:-.4px;flex-shrink:0;margin-right:18px;white-space:nowrap}.search-box{flex:0 1 520px;position:relative;min-width:220px}.search-box input{width:100%;height:44px;background:#fff;border:1.5px solid rgba(0,0,0,.16);border-radius:var(--radius-xl);padding:0 16px 0 44px;font-size:16px;color:var(--text-primary);transition:all var(--transition-fast)}.search-box input::placeholder{color:#64748b}.search-box input:focus{outline:none;border-color:var(--abbott-indigo);box-shadow:0 0 0 3px rgba(0,0,117,.12)}.search-box>.material-icons-outlined{position:absolute;left:13px;top:50%;transform:translateY(-50%);font-size:19px;color:var(--text-secondary);pointer-events:none}.topbar-spacer{flex:1}.topbar-actions{display:flex;align-items:center;gap:6px;flex-shrink:0}.topbar-btn{width:38px;height:38px;border-radius:50%;background:rgba(0,0,0,.04);color:var(--text-secondary);display:flex;align-items:center;justify-content:center;transition:all var(--transition-fast);position:relative}.topbar-btn:hover{background:rgba(0,0,0,.08);color:var(--text-primary)}.topbar-btn .dot{position:absolute;top:7px;right:7px;width:7px;height:7px;border-radius:50%;background:var(--accent-red);border:2px solid #fff}
.switch-classic-btn{
    height:36px;
    padding:0 14px;
    border:1px solid #000075;
    border-radius:18px;
    background:#fff;
    color:#000075;
    display:inline-flex;
    align-items:center;
    gap:6px;
    font-size:13px;
    font-weight:600;
    white-space:nowrap;
    transition:all var(--transition-fast);
}
.switch-classic-btn:hover{
    background:#000075;
    color:#fff;
}
.switch-classic-btn .material-icons-outlined{
    font-size:17px;
}
.user-menu{display:flex;align-items:center;gap:8px;padding:4px 10px 4px 4px;border-radius:var(--radius-xl);cursor:pointer;transition:background var(--transition-fast)}.user-menu:hover{background:rgba(0,0,0,.04)}.user-menu .u-circle{width:34px;height:34px}.user-menu-name{font-size:13.5px;font-weight:600;color:var(--text-primary)}
.u-circle{
    background:transparent;
    color:#fff;
}

.user-profile-icon{
    font-size:30px !important;
    line-height:1;
    color:#fff;
}

/* Header profile icon and dropdown sizing */
.profile-wrap{
    position:relative;
}

.header-profile-icon-wrap{
    width:38px !important;
    height:38px !important;
    background:#000075 !important;
    border:2px solid #dbe4ff;
    color:#fff !important;
    box-shadow:0 1px 4px rgba(0,0,0,.14);
}

.header-profile-icon{
    font-size:28px !important;
    color:#fff !important;
    opacity:1 !important;
}

.dropdown-profile-icon{
    font-size:58px !important;
    line-height:1;
    color:#fff;
}

.profile-dropdown{
    width:420px;
    max-width:calc(100vw - 24px);
    border-radius:8px;
}

.profile-top{
    min-height:150px;
    height:auto;
    padding:24px;
}

.profile-big-avatar{
    width:92px;
    height:92px;
}

.profile-name{
    font-size:20px;
}

.profile-email{
    font-size:13px;
}
/* Search results modal */
.search-modal-overlay{position:fixed;inset:0;background:transparent;z-index:998;display:none}.search-modal{position:fixed;top:64px;left:0;width:520px;max-width:calc(100vw - 24px);max-height:520px;background:#fff;border-radius:0 0 14px 14px;box-shadow:0 14px 40px rgba(15,23,42,.18);z-index:1000;display:none;overflow:hidden}.search-modal.active,.search-modal-overlay.active{display:block}.search-modal-body{max-height:520px;overflow-y:auto;padding:0}.search-section{padding:12px 18px 14px;border-bottom:1px solid #e5e7eb}.search-section-title{font-size:13px;color:#94a3b8;margin-bottom:8px}.search-item{display:flex;align-items:flex-start;gap:12px;padding:12px 0;border-bottom:1px solid #e5e7eb}.search-item:last-child{border-bottom:0}.search-thumb{width:38px;height:38px;border-radius:8px;background:#f1f5f9;display:flex;align-items:center;justify-content:center;color:#000075;flex-shrink:0}.search-thumb .material-icons-outlined{font-size:22px}.search-title{font-size:15px;font-weight:700;color:#020617;margin-bottom:4px}.search-desc{font-size:13px;line-height:1.4;color:#7b8794}.search-empty{padding:28px;text-align:center;color:#64748b;font-size:14px}

/* Page */
.page{flex:1;padding:28px 32px;width:100%;max-width:none}.hero{background:linear-gradient(135deg,#1e0a6e 0%,#0d47a1 40%,#0277bd 70%,#00838f 100%);color:#fff;border-radius:var(--radius-xl);padding:48px;margin-bottom:28px;position:relative;overflow:hidden}.hero::before{content:'';position:absolute;inset:0;background:radial-gradient(ellipse 80% 100% at 90% 20%,rgba(151,163,245,.3) 0%,transparent 50%),radial-gradient(ellipse 60% 80% at 10% 80%,rgba(0,156,222,.2) 0%,transparent 50%);pointer-events:none}.hero::after{content:'';position:absolute;right:-60px;top:-60px;width:400px;height:400px;border-radius:50%;border:60px solid rgba(255,255,255,.03);pointer-events:none}.hero-content{position:relative;z-index:1}.hero-greeting{font-size:40px;font-weight:300;letter-spacing:-.5px;margin-bottom:6px;line-height:1.15;text-shadow:0 2px 20px rgba(0,0,0,.15)}.hero-greeting strong{font-weight:800}.hero-sub{font-size:14px;color:rgba(255,255,255,.75);margin-bottom:28px}.hero-stats{display:flex;gap:14px;flex-wrap:wrap}.hero-stat{background:rgba(255,255,255,.12);border:1px solid rgba(255,255,255,.15);border-radius:var(--radius-md);padding:16px 22px;backdrop-filter:blur(8px);transition:all var(--transition-fast);min-width:130px}.hero-stat:hover{background:rgba(255,255,255,.2);transform:translateY(-2px)}.hero-stat-val{font-size:26px;font-weight:800;letter-spacing:-.5px}.hero-stat-label{font-size:11px;color:rgba(255,255,255,.65);margin-top:2px;font-weight:600;text-transform:uppercase;letter-spacing:.5px}
.sec-hdr{display:flex;align-items:center;justify-content:space-between;margin-bottom:14px}.sec-hdr h2{display:flex;align-items:center;gap:8px;font-size:17px;font-weight:700}.sec-hdr h2 .material-icons-outlined{font-size:20px;color:var(--abbott-indigo)}.sec-link{font-size:12.5px;color:var(--abbott-indigo);font-weight:600;cursor:pointer;display:flex;align-items:center;gap:3px}.sec-link:hover{color:var(--abbott-bright)}

/* Cards */
.fav-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:18px;margin-bottom:36px}.fav-card{background:#fff;border-radius:16px;padding:24px 26px;min-height:150px;border:1px solid rgba(0,0,0,.06);box-shadow:0 4px 18px rgba(15,23,42,.10);position:relative;transition:.25s ease;overflow:hidden}.fav-card:hover{transform:translateY(-3px);box-shadow:var(--shadow-elevated)}
.fav-close{
    position: absolute;
    top: 12px;
    right: 12px;
    width: 26px;
    height: 26px;
    border-radius: 50%;
    background: #fee2e2;
    color: #b91c1c;
    border: 1px solid #fecaca;

    display: flex;
    align-items: center;
    justify-content: center;

    font-size: 14px;      /* reduce from 18px */
    font-weight: 700;
    line-height: 1;        /* instead of 22px */

    padding: 0;            /* important */
    opacity: 0;
    z-index: 5;
    transition: .2s ease;
}

.fav-card:hover .fav-close{
    opacity: 1;
}

.fav-close:hover{
    background: #dc2626;
    color: #fff;
    transform: scale(1.08);
}
.fav-close{
    transform: translateY(1px);
}
.fav-star{position:absolute;right:48px;top:16px;color:#d97706;font-size:18px}.fav-ico{width:46px;height:46px;border-radius:9px;background:#f0edff;color:#000075;display:flex;align-items:center;justify-content:center;margin-bottom:16px}.fav-card h3{font-size:16px;font-weight:700;color:#1e293b;margin-bottom:8px}.fav-card p{font-size:14px;line-height:1.45;color:#8ca0bc;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden}.empty{grid-column:1/-1;background:#fff;border:2px dashed #cbd5e1;border-radius:16px;padding:26px;color:#64748b;text-align:center}
.rpt-grid{display:grid;grid-template-columns:repeat(5,1fr);gap:12px;margin-bottom:36px}.rpt-card{background:#fff;border-radius:var(--radius-md);padding:14px 16px;min-height:64px;border:1px solid rgba(0,0,0,.06);cursor:pointer;transition:all var(--transition-fast);display:flex;align-items:center;gap:10px}.rpt-card:hover{background:var(--surface-card-hover);border-color:rgba(0,0,117,.12);transform:translateX(3px)}.rpt-ico{width:34px;height:34px;border-radius:var(--radius-sm);background:rgba(0,0,117,.06);display:flex;align-items:center;justify-content:center;flex-shrink:0}.rpt-ico .material-icons-outlined{font-size:17px;color:var(--abbott-indigo)}.rpt-card span{font-size:14px;font-weight:600;line-height:1.2}
.top-report-fav-star{
    margin-left:auto;
    font-size:19px !important;
    color:#cbd5e1;
    cursor:pointer;
    flex-shrink:0;
}
.top-report-fav-star.active{color:#f59e0b}
.top-report-fav-star:hover{color:#fbbf24}
.bottom{display:grid;grid-template-columns:1fr 1fr;gap:20px;margin-bottom:28px}.panel{background:#fff;border-radius:var(--radius-lg);border:1px solid rgba(0,0,0,.06);box-shadow:var(--shadow-card);overflow:hidden}.panel-hdr{padding:18px 22px;border-bottom:1px solid rgba(0,0,0,.06);display:flex;align-items:center;justify-content:space-between}.panel-hdr h3{font-size:14px;font-weight:700;display:flex;align-items:center;gap:7px}.panel-hdr h3 .material-icons-outlined{font-size:18px;color:var(--abbott-indigo)}.panel-body{padding:4px 0}.act-item{display:flex;align-items:center;gap:12px;padding:10px 22px;cursor:pointer;transition:background var(--transition-fast)}.act-item:hover{background:rgba(0,0,0,.015)}.act-dot{width:30px;height:30px;border-radius:50%;display:flex;align-items:center;justify-content:center;flex-shrink:0}.act-dot.c1{background:rgba(0,0,117,.07);color:var(--abbott-indigo)}.act-dot.c2{background:rgba(5,150,105,.07);color:var(--accent-green)}.act-dot.c3{background:rgba(217,119,6,.07);color:var(--accent-amber)}.act-text{flex:1;min-width:0}.act-text strong{font-size:13px;font-weight:500;display:block}.act-text small{font-size:11px;color:var(--text-tertiary)}.act-time{font-size:11px;color:var(--text-tertiary);white-space:nowrap}.ql{display:flex;align-items:center;gap:12px;padding:12px 22px;cursor:pointer;transition:all var(--transition-fast)}.ql:hover{background:rgba(0,0,0,.015)}.ql-ico{width:34px;height:34px;border-radius:var(--radius-sm);display:flex;align-items:center;justify-content:center;flex-shrink:0;font-size:17px}.ql-text{flex:1}.ql-text strong{font-size:13.5px;font-weight:600;display:block}.ql-text small{font-size:11px;color:var(--text-tertiary)}.ql-arr{color:var(--text-tertiary);font-size:17px;transition:transform var(--transition-fast)}.ql:hover .ql-arr{transform:translateX(3px);color:var(--abbott-indigo)}
.app-footer{padding:18px 32px;border-top:1px solid rgba(0,0,0,.06);display:flex;align-items:center;justify-content:space-between;font-size:12px;color:var(--text-tertiary);gap:16px}.footer-left{display:flex;align-items:center;gap:12px}.footer-left svg{height:14px;width:auto;color:var(--abbott-indigo);opacity:.5}.footer-links{display:flex;gap:20px}.footer-links a{color:var(--text-tertiary)}.footer-links a:hover{color:var(--text-secondary)}

@keyframes fadeUp{from{opacity:0;transform:translateY(10px)}to{opacity:1;transform:translateY(0)}}.hero{animation:fadeUp .4s ease-out}.fav-grid{animation:fadeUp .4s ease-out .06s both}.rpt-grid{animation:fadeUp .4s ease-out .12s both}.bottom{animation:fadeUp .4s ease-out .18s both}

.pbi-dashboard-group{margin-bottom:24px}.pbi-dashboard-group-title{font-size:14px;font-weight:700;color:var(--text-secondary);margin:0 0 10px 2px}

/* Responsive */
@media(max-width:1400px){.rpt-grid{grid-template-columns:repeat(4,1fr)}}
@media(max-width:1200px){.topbar-title{font-size:30px}.fav-grid{grid-template-columns:repeat(3,1fr)}.rpt-grid{grid-template-columns:repeat(3,1fr)}}
@media(max-width:992px){.bottom{grid-template-columns:1fr}.topbar-title{font-size:26px}.search-box{flex:1 1 320px}.page{padding:22px}.hero{padding:36px}.fav-grid{grid-template-columns:repeat(2,1fr)}}
@media(max-width:768px){
  :root{--header-height:112px;--sidebar-width:280px}
  .side{transform:translateX(-100%)}.side.open{transform:translateX(0)}.main{margin-left:0}.hamburger{display:flex;order:1}.top-bar{height:auto;min-height:112px;padding:10px 14px;gap:10px;flex-wrap:wrap}.topbar-title{order:2;font-size:22px;flex:1;margin-right:0;min-width:0;overflow:hidden;text-overflow:ellipsis}.topbar-actions{order:3}.topbar-spacer{display:none}.search-box{order:4;flex:0 0 100%;width:100%;min-width:0}.search-box input{height:42px;font-size:14px}.user-menu-name{display:none}.topbar-btn{width:34px;height:34px}.user-menu{padding:2px}.user-menu .u-circle{width:32px;height:32px}.page{padding:16px}.hero{padding:28px 22px;border-radius:16px}.hero-greeting{font-size:28px}.hero-sub{font-size:12px;margin-bottom:18px}.hero-stat{flex:1 1 calc(50% - 8px);min-width:0;padding:13px 14px}.hero-stat-val{font-size:22px}.fav-grid{grid-template-columns:1fr 1fr;gap:12px}.fav-card{padding:18px;min-height:136px}.fav-close{opacity:1}.rpt-grid{grid-template-columns:1fr 1fr}.rpt-card{padding:12px;min-height:58px}.search-modal{top:112px!important;left:12px!important;right:12px!important;width:auto!important;max-width:none;max-height:65vh;border-radius:12px;transform:none!important}.search-modal-body{max-height:65vh}.search-section{padding:10px 14px}.search-item{gap:10px;padding:11px 0}.search-title{font-size:14px}.search-desc{font-size:12px}.app-footer{padding:16px;flex-direction:column;align-items:flex-start}.footer-links{gap:14px}.side-backdrop{position:fixed;inset:0;background:rgba(15,23,42,.35);z-index:180;display:none}.side.open~.side-backdrop{display:block}
}
@media(max-width:480px){.topbar-title{font-size:19px}.page{padding:12px}.hero{padding:22px 16px}.hero-greeting{font-size:24px}.hero-stats{gap:10px}.hero-stat{flex:1 1 100%}.fav-grid,.rpt-grid{grid-template-columns:1fr}.bottom{gap:14px}.panel-hdr{padding:15px 16px}.act-item,.ql{padding:10px 16px}.fav-card{padding:18px}.search-thumb{width:34px;height:34px}.search-thumb .material-icons-outlined{font-size:20px}.search-empty{padding:22px 14px}.side{width:86vw;max-width:300px}}
.hero{
    background:
      linear-gradient(
        90deg,
        rgba(5,4,107,.92) 0%,
        rgba(14,62,170,.82) 45%,
        rgba(14,62,170,.20) 75%
      ),
      url('/gsr/common/images/banner_background_img.jpg');

    background-size:cover;
    background-position:center;
}
.nav-sub{
    display:flex;
    align-items:center;
    gap:8px;
    padding:8px 20px 8px 52px;
    font-size:14px;
    color:rgba(255,255,255,.65);
}

.fav-icon{
    font-size:14px !important;
    color:#f59e0b; /* Gold Star */
    flex-shrink:0;
}

.nav-sub:hover .fav-icon{
    color:#fbbf24;
}
.profile-wrap{
    position:relative;
}

/* Profile Dropdown */
.profile-dropdown{
    position:absolute;
    top:58px;
    right:-30px;          /* Align to the extreme right */
    width:380px;
    background:#fff;
    border-radius:0;
    
    overflow:hidden;
    display:none;
    z-index:9999;
}

.profile-dropdown.active{
    display:block;
}

.profile-top {
    height: 125px;
    padding: 18px;
    display: flex;
    align-items: center;
    gap: 18px;
    color: #fff;
    background: linear-gradient(135deg, #02006b 0%, #006fba 55%, #18a9d6 100%);
}

.profile-big-avatar {
    width: 86px;
    height: 86px;
    border-radius: 50%;
    background: #c9ceff;
    border: 5px solid rgba(255,255,255,.85);
    color: #000075;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 32px;
    font-weight: 800;
    flex-shrink: 0;
    overflow: hidden;
}

.profile-big-avatar img,
.u-circle img {
    width: 100%;
    height: 100%;
    border-radius: 50%;
    object-fit: cover;
}

.profile-top-info {
    flex: 1;
    min-width: 0;
}

.profile-name {
    font-size: 18px;
    font-weight: 800;
    color: #fff;
    line-height: 1.2;
}

.profile-email {
    font-size: 12px;
    color: rgba(255,255,255,.92);
    margin-top: 5px;
    word-break: break-all;
}

.profile-role {
    height: 42px;
    padding: 0 16px;
    display: flex;
    align-items: center;
    gap: 8px;
    background: #fff;
    font-size: 13px;
    color: #475569;
    border-bottom: 1px solid #e5e7eb;
}

.profile-role .material-icons-outlined {
    font-size: 17px;
    color: #64748b;
}

.profile-bottom {
    height: 48px;
    padding: 0 14px;
    background: #fff;
    display: flex;
    align-items: center;
    justify-content: space-between;
}

.profile-logo {
    font-size: 18px;
    font-weight: 900;
    color: #000075;
    letter-spacing: .4px;
}

.signout-btn {
    height: 28px;
    background: #d9283b;
    color: #fff;
    padding: 0 11px;
    border-radius: 2px;
    font-size: 12px;
    font-weight: 700;
    display: flex;
    align-items: center;
    gap: 5px;
}

.signout-btn:hover {
    background: #b91c1c;
}

.signout-btn .material-icons-outlined {
    font-size: 15px;
}
.search-info {
    flex: 1;
    min-width: 0;
}

.search-title-row {
    display: flex;
    align-items: center;
    gap: 8px;
}

.search-title {
    flex: 1;
}

.search-fav-star {
    font-size: 15px !important;
    color: #f59e0b;
    flex-shrink: 0;
}
.nav-sub  {
    color: #fff !important;
}
.nav-sub:hover {
   color: rgba(255, 255, 255, .65) !important;
}
.nav-sub{
    position: relative;
    padding-right: 18px !important;
}

.nav-sub .fav-icon{
    margin-left: auto;
    font-size: 15px !important;
    color: rgba(255,255,255,.35);
    cursor: pointer;
    flex-shrink: 0;
}

.nav-sub .fav-icon.active{
    color: #f59e0b;
}

.nav-sub:hover .fav-icon{
    color: #fbbf24;
}

.nav-sub .nav-sub-icon{
    flex-shrink: 0;
}
.search-fav-star{
    font-size: 18px !important;
    color: #cbd5e1;
    cursor: pointer;
    flex-shrink: 0;
}

.search-fav-star.active{
    color: #f59e0b;
}

.search-fav-star:hover{
    color: #fbbf24;
}

.search-validation-tick{
    width:18px;
    height:18px;
    object-fit:contain;
    flex-shrink:0;
}

.sidebar-toggle{
    position:absolute;
    top:82px;
    right:-15px;
    width:30px;
    height:30px;
    border-radius:50%;
    background:#fff;
    color:#000075;
    box-shadow:0 3px 10px rgba(0,0,0,.25);
    z-index:500;
    display:flex;
    align-items:center;
    justify-content:center;
}

.side.collapsed{
    width:78px;
}

.side.collapsed .side-product,
.side.collapsed .nav-grp-label,
.side.collapsed .nav-item,
.side.collapsed .nav-sub,
.side.collapsed .u-name,
.side.collapsed .u-role,
.side.collapsed .nav-chev{
    white-space:nowrap;
}

.side.collapsed .side-product,
.side.collapsed .nav-grp-label,
.side.collapsed .nav-item:not(.active) > span:not(.material-icons-outlined),
.side.collapsed .nav-sub{
    display:none;
}

.side.collapsed .side-hdr,
.side.collapsed .side-ft{
    padding-left:14px;
    padding-right:14px;
}

.side.collapsed + .side-backdrop + .main,
.side.collapsed ~ .main{
    margin-left:78px;
}
/* Production validation tick */
.validation-tick{
    width:20px;
    height:20px;
    object-fit:contain;
    flex:0 0 64px;
    display:block;
}
.nav-validation-tick{
    margin-left:auto;
}
.nav-sub .nav-validation-tick + .fav-icon{
    margin-left:0;
}
.top-report-validation-tick{
    margin-left:auto;
}
.top-report-card .top-report-validation-tick + .top-report-fav-star{
    margin-left:0;
}
.fav-title-row{
    display:flex;
    align-items:center;
    gap:8px;
    margin-bottom:8px;
}
.fav-title-row h3{
    margin-bottom:0;
    flex:1;
    min-width:0;
}
.fav-validation-tick{
    margin-left:auto;
}

.panel-bi {
    border:1px solid #e3e7ec;
    padding:10px 20px;    
    box-shadow:var(--shadow-card);
    margin-bottom:25px;
	border-radius:10px;
}
.pi-head {
	margin-bottom:30px;
	margin-top:20px;
}


/* Requested dashboard UI corrections */
/* 1. Remove the outer border/container styling from PowerBI Clearinghouse. */
.panel-bi{
    border:none;
    box-shadow:none;
    border-radius:0;
    padding:0;
    background:transparent;
}

/* 2. Favorites cards: use the same hover effect as Top 15 Used Reports. */
.fav-card{
    box-shadow:none;
    transform:none;
}

.fav-card:hover{
    background:var(--surface-card-hover);
    border-color:rgba(0,0,117,.12);
    box-shadow:none;
    transform:translateX(3px);
}

/* Favorites close button: keep the X exactly centered inside the circle. */
.fav-close{
    display:block;
    padding:0;
    font-size:0;
    line-height:0;
    text-align:center;
    transform:none;
}

.fav-close::before{
    content:"×";
    position:absolute;
    left:50%;
    top:50%;
    transform:translate(-50%,-52%);
    font-family:Arial, Helvetica, sans-serif;
    font-size:16px;
    font-weight:700;
    line-height:1;
}

.fav-close:hover{
    transform:scale(1.08);
}

/* 3. Keep consistent spacing for every left sidebar menu entry. */
.nav-item,
.nav-sub{
    padding:20px 18px;
}

/* Preserve a small visual indent for child reports while keeping 20px vertical spacing. */
.nav-sub{
    padding-left:38px;
}

</style>
</head>
<body>
<div class="app">
<aside class="side" id="sidebar">
  <div class="side-hdr">
    <div class="abbott-logo"><svg viewBox="0 0 192 30" fill="currentColor" xmlns="http://www.w3.org/2000/svg" aria-label="Abbott"><path d="M30.97 .72H0v4.68h29.54c.91 0 1.46.61 1.46 1.51v16.18c0 .9-.55 1.51-1.46 1.51H6.14c-.91 0-1.46-.6-1.46-1.51v-6.59c0-.9.55-1.51 1.46-1.51h20.02v-4.69H4.72C2 10.31 0 12.35 0 15.03v9.54c0 2.67 2 4.72 4.72 4.72h26.27c2.72 0 4.7-2.06 4.7-4.73V5.44C35.69 2.78 33.69.71 30.97.71"/><path d="M56.04 17.44l4.46-11.95h.2l4.33 11.95h-8.99zm7.38-16.93h-4.46L50.08 24.01c-1.3 3.44-2.17 4.41-2.97 5.26v.23h6.33v-.23c-.46-.54-.61-1.24-.61-1.93 0-1.09.39-2.33.76-3.33l1.31-3.5h11.25l1.51 4.16c.31.85.5 1.62.5 2.4 0 .77-.19 1.43-.61 2.2l-.04.23h7.62v-.23c-1.18-1.2-1.83-2.51-2.55-4.45L63.43.5z"/><path d="M87.04 26.44H82.08V3.56h4.77c2.9 0 5.76.89 5.76 4.31 0 3.42-2.94 4.74-5.91 4.74h-2.44v3.05h2.55c3.28 0 7.24.89 7.24 5.37 0 4.1-3.32 5.41-7.02 5.41m3.24-12.29v-.19c4.31-.46 6.86-2.94 6.86-6.77 0-4.68-3.74-6.69-8.92-6.69H76.14v.23c.91 1 1.45 2.32 1.45 4.29v19.95c0 1.97-.54 3.28-1.45 4.29v.23h13c5.64 0 9.49-3.02 9.49-8.08 0-5.06-3.58-6.98-8.35-7.25"/><path d="M110.13 26.44h-4.96V3.56h4.77c2.9 0 5.76.89 5.76 4.31 0 3.42-2.94 4.74-5.91 4.74h-2.44v3.05h2.55c3.28 0 7.24.89 7.24 5.37 0 4.1-3.32 5.41-7.02 5.41m3.24-12.29v-.19c4.31-.46 6.86-2.94 6.86-6.77 0-4.68-3.74-6.69-8.92-6.69H99.22v.23c.92 1 1.45 2.32 1.45 4.29v19.95c0 1.97-.53 3.28-1.45 4.29v.23h13c5.64 0 9.49-3.02 9.49-8.08 0-5.06-3.58-6.98-8.35-7.25"/><path d="M137.44 26.71c-6.16 0-10.03-5.18-10.03-11.71 0-6.53 3.9-11.71 10.03-11.71 6.12 0 10.03 5.18 10.03 11.71 0 6.53-3.87 11.71-10.03 11.71zm0-26.71C128.75 0 122.69 6.46 122.69 15s6.06 15 14.75 15 14.76-6.42 14.76-15S146.13 0 137.44 0z"/><path d="M150.99.5v5.14h.22c.75-1.16 2.12-2.09 5.02-2.09h4.4v21.42c0 1.93-.5 3.29-1.41 4.29v.23h7.32v-.23c-.88-1-1.41-2.36-1.41-4.29V3.56h12.72v21.42c0 1.93-.57 3.29-1.45 4.29v.23h7.4v-.23c-.92-1-1.45-2.36-1.45-4.29V3.56h4.35c2.9 0 4.31.93 5.07 2.09h.23V.5H150.99z"/></svg></div>
    <div class="side-product">Global Service Reports</div>
  </div>
  <nav class="side-nav">
  <div>
    <a class="nav-item active" href="javascript:void(0);">
      <span class="material-icons-outlined">home</span>Home
    </a>
  </div>

  <?php if (!empty($menu_data['items'])) { ?>
    <div class="nav-grp-label">Reports</div>

 <?php
$parentIndex = 0;
foreach ($menu_data['items'] as $idx => $group) {
    // Group title/icon come directly from GSR_ADMIN_GUI_MENUS (L2 = 0 row).
    $group_title = (string)($group['title'] ?? '');
    $database_group_icon = (string)($group['icon'] ?? '');

    // Group title always comes from the database.
    if ($group_title === '') {
        continue;
    }

    // Use the requested matching icon when configured.
    // If a database group is not in the map, keep its database icon as fallback.
    $group_icon = $menu_icon_map[$group_title] ?? $database_group_icon;
    if ($group_icon === '') {
        $group_icon = 'folder';
    }

    $isFirst = ($parentIndex === 0);
?>
    <div class="nav-item <?php echo $isFirst ? 'expanded' : ''; ?>" data-expand>
        <?php echo renderMenuIcon($group_icon, 'folder'); ?>
        <?php echo htmlspecialchars((string)($group_title), ENT_QUOTES, 'UTF-8'); ?>
        <span class="material-icons-outlined nav-chev">chevron_right</span>
    </div>

    <?php if (!empty($group['items'])) { ?>
        <div class="nav-subs">
		
            <?php foreach ($group['items'] as $item) {
                $item_title = (string)($item['title'] ?? 'Unknown');
                $item_link  = $item['link'] ?? '#';
                $item_desc  = $item['desc'] ?? '';
            ?>
                <a class="nav-sub fav-sub draggable-report"
   draggable="true"
   target="_blank"
   href="<?php echo htmlspecialchars((string)($item_link), ENT_QUOTES, 'UTF-8'); ?>"
   data-fav-name="<?php echo htmlspecialchars((string)($item_title), ENT_QUOTES, 'UTF-8'); ?>"
   data-fav-href="<?php echo htmlspecialchars((string)($item_link), ENT_QUOTES, 'UTF-8'); ?>"
   data-fav-desc="<?php echo htmlspecialchars((string)($item_desc), ENT_QUOTES, 'UTF-8'); ?>"
   data-validated-for-prod="<?php echo htmlspecialchars((string)($item['validated_for_prod'] ?? 'N'), ENT_QUOTES, 'UTF-8'); ?>">
   <span class="material-icons-outlined nav-sub-icon">description</span>
   <?php echo htmlspecialchars((string)($item_title), ENT_QUOTES, 'UTF-8'); ?>

   <?php if (strtoupper((string)($item['validated_for_prod'] ?? 'N')) === 'Y') { ?>
       <img src="/gsr/common/images/green-check-mark-circular-64.png"
            class="validation-tick nav-validation-tick"
            width="64"
            height="64"
            alt="Validated for production"
            title="Validated for production">
   <?php } ?>

   <span class="material-icons-outlined fav-icon "
      title="Add to Favorites">
    star_border
</span>
</a>
            <?php } ?>
        </div>
    <?php } ?>

<?php
    $parentIndex++;
}
?>
  <?php } ?>

  <?php if (!empty($powerbi_dashboard_groups)) {
      $sidebar_powerbi_reports = array();
      foreach ($powerbi_dashboard_groups as $powerbi_group) {
          if (!empty($powerbi_group['items'])) {
              $sidebar_powerbi_reports = array_merge($sidebar_powerbi_reports, $powerbi_group['items']);
          }
      }
  ?>
    <div class="nav-item" data-expand>
      <span class="material-icons-outlined">analytics</span>
      Power BI Reports
      <span class="material-icons-outlined nav-chev">chevron_right</span>
    </div>
    <div class="nav-subs">
      <?php foreach ($sidebar_powerbi_reports as $powerbi_sidebar_report) { ?>
        <a class="nav-sub"
           target="_blank"
           rel="noopener noreferrer"
           href="<?php echo htmlspecialchars((string)($powerbi_sidebar_report['link'] ?? '#'), ENT_QUOTES, 'UTF-8'); ?>">
          <span class="material-icons-outlined nav-sub-icon">analytics</span>
          <?php echo htmlspecialchars((string)($powerbi_sidebar_report['title'] ?? 'Power BI Report'), ENT_QUOTES, 'UTF-8'); ?>
        </a>
      <?php } ?>
    </div>
  <?php } ?>
</nav>
  
</aside>
<div class="side-backdrop" id="sideBackdrop"></div>

<main class="main">
  <header class="top-bar">
    <button class="hamburger" onclick="document.getElementById('sidebar').classList.toggle('open')"><span class="material-icons-outlined">menu</span></button>
    <div class="topbar-title">Global Service Reports</div>
   
	
	<div class="search-box" id="globalSearchBox">
    <span class="material-icons-outlined">search</span>
    <input id="globalSearchInput" type="text"
           placeholder="Search reports, instruments, categories..."
           autocomplete="off">
</div>
	
	
    <div class="topbar-spacer"></div>
    <div class="topbar-actions">
	 <a class="switch-classic-btn"
         href="?switch_experience=classic"
         title="Switch to Classic GSR">
        <span class="material-icons-outlined">swap_horiz</span>
        Switch to Classic View
      </a>
      <button class="topbar-btn" title="Help"><a href="<?php echo $gsr_base_url.'help'; ?>" target="_blank"><span class="material-icons-outlined">help_outline</span></a></button>

      
     <div class="profile-wrap" id="profileWrap">
    <a class="user-menu" href="javascript:void(0);" id="profileBtn">
        <div class="u-circle header-profile-icon-wrap">
            <span class="material-icons-outlined user-profile-icon header-profile-icon">account_circle</span>
        </div>
        <span class="user-menu-name">
            <?php echo htmlspecialchars((string)($display_name), ENT_QUOTES, 'UTF-8'); ?>
        </span>
    </a>

    <div class="profile-dropdown" id="profileDropdown">

        <div class="profile-top">
            <div class="profile-big-avatar">
                <span class="material-icons-outlined dropdown-profile-icon">account_circle</span>
            </div>

            <div class="profile-top-info">
                <div class="profile-name">
                    <?php echo htmlspecialchars((string)($display_name), ENT_QUOTES, 'UTF-8'); ?>
                </div>

                <div class="profile-email">
                    <?php echo htmlspecialchars((string)($_SERVER['HTTP_REMOTE_EMAIL'] ?? ''), ENT_QUOTES, 'UTF-8'); ?>
                </div>
            </div>
        </div>

        <div class="profile-role">
            <span class="material-icons-outlined">admin_panel_settings</span>
            <?php echo htmlspecialchars((string)($_SESSION['azure_auth_employeeType'] ?? ''), ENT_QUOTES, 'UTF-8'); ?>
        </div>

        <div class="profile-bottom">
            <div class="profile-logo"><img width='100px' src='/gsr/common/images/abbottNewLogo.png'></div>

            <a class="signout-btn" href="<?php echo htmlspecialchars((string)($logout_url), ENT_QUOTES, 'UTF-8'); ?>">
                <span class="material-icons-outlined">logout</span>
                Sign out
            </a>
        </div>

    </div>
</div>
    </div>
  </header>
  <div class="search-modal-overlay" id="searchModalOverlay"></div>

<div class="search-modal" id="searchModal">
    <div class="search-modal-body" id="searchModalBody"></div>
</div>
	<script>
		  window.GSR_SEARCH_DATA = <?php echo json_encode($search_items); ?>;
			window.GSR_FAVORITES = [];
	</script>
  <?php 
$parent_group_count = count($menu_data['items'] ?? array());

$child_report_count = 0;
foreach (($menu_data['items'] ?? array()) as $group) {
    $child_report_count += count($group['items'] ?? array());
}

/* Active GSR count is based on qualifying usage-report names from the last
   three completed months. Development Items and Power BI reports are excluded.
   Fall back to the visible GSR menu child count if the usage query is unavailable. */
$display_report_count = $usage_data_loaded
    ? $active_report_count
    : $child_report_count;

$last_login_time = '';
if (!empty($_SESSION['azure_auth_IssueInstant'])) {
    $dt = new DateTime($_SESSION['azure_auth_IssueInstant']);
    $dt->setTimezone(new DateTimeZone(date_default_timezone_get()));
    $last_login_time = $dt->format('d M Y, h:i A T');
}
?>
  <div class="page">
    <section class="hero">
      <div class="hero-content">
        <h1 class="hero-greeting">Hello, <strong><?php echo htmlspecialchars((string)($display_name), ENT_QUOTES, 'UTF-8'); ?>.</strong></h1>
        <div class="hero-sub" id="heroDate"></div>
        <div class="hero-stats">
          <div class="hero-stat"
               title="Usage logic: <?php echo htmlspecialchars((string)($usage_period_label), ENT_QUOTES, 'UTF-8'); ?>">
            <div class="hero-stat-val">
              <?php echo number_format($display_report_count); ?>
            </div>
            <div class="hero-stat-label">Active Reports</div>
          </div>
		 
			<div class="hero-stat" id="powerbiReportCard" style="cursor:pointer;">
				<div class="hero-stat-val">
					<?php echo number_format($powerbi_report_count); ?>
				</div>
				<div class="hero-stat-label">
					POWER BI Reports
				</div>
			</div>
		 
          <div class="hero-stat">
			<div class="hero-stat-val">
				<?php echo number_format($current_month_unique_users); ?>
			</div>
			<div class="hero-stat-label">Monthly Active Users</div>
		</div>
		 <div class="hero-stat">
			<div class="hero-stat-val">
				<?php echo htmlspecialchars((string)($current_month_login_user_count), ENT_QUOTES, 'UTF-8'); ?>
			</div>
			<div class="hero-stat-label">Users Logged in Current Month</div>
		</div>
         
          <div class="hero-stat">
			<div class="hero-stat-val">
				<?php echo htmlspecialchars((string)($last_login_time), ENT_QUOTES, 'UTF-8'); ?>
			</div>
			<div class="hero-stat-label">Last Login Time</div>
		</div>
        </div>
      </div>
    </section>
	
    <section>
	<div class="sec-hdr"><h2><span class="material-icons-outlined">star</span>Favorites</h2></div>
      
	  <div class="fav-grid" id="favoritesBody"></div>
    </section>

	 <?php if (!empty($top_reports)) { ?>
    <section class="section">
      <div class="sec-hdr"><h2 title="For last 3 months"><span class="material-icons-outlined">trending_up</span>Top 15 Used Reports</h2></div>
      <div class="rpt-grid">
        <?php
          $tileClasses = array('t-blue','t-green','t-amber','t-purple','t-cyan','t-red');
          $i = 0;
          foreach ($top_reports as $report) {
            $tile = $tileClasses[$i % count($tileClasses)];
            $i++;
            $title = $report['title'] ?? '';
            $desc = $report['desc'] ?? '';
            $link = $report['link'] ?? '#';
            $count = (int)($report['kount'] ?? 0);
            $validatedForProd = strtoupper((string)($report['validated_for_prod'] ?? 'N'));
        ?>
       
		  
		  
		  <?php
		$reportIcons = array(
			'Instrument Search' => 'manage_search',
			'Service Capacity Model' => 'speed',
			'Country Reports' => 'public',
			'Ticket Search' => 'confirmation_number',
			'CRL Management Report' => 'assignment',
			'TSB Viewer' => 'article',
			'Parts Viewer' => 'precision_manufacturing',
			'Assay Report' => 'science',
			'SIFT Viewer' => 'visibility',
			'Contact Center Reports' => 'support_agent',
			'Service Contract Viewer' => 'description',
			'Service Manager Reports' => 'supervisor_account',
			'Installed Base Viewer' => 'inventory_2',
			'FASTR' => 'bolt',
			'Timeliness Viewer' => 'schedule',
			'Installation Metrics' => 'construction',
			'Service Business Review' => 'analytics',
			'Uptime' => 'trending_up'
		);

		$iconName = $reportIcons[$title] ?? 'dashboard';
		?>

<a class="rpt-card top-report-card"
   target="_blank"
   href="<?php echo htmlspecialchars((string)($link), ENT_QUOTES, 'UTF-8'); ?>"
   data-title="<?php echo htmlspecialchars((string)($title), ENT_QUOTES, 'UTF-8'); ?>"
   data-fav-name="<?php echo htmlspecialchars((string)($title), ENT_QUOTES, 'UTF-8'); ?>"
   data-fav-href="<?php echo htmlspecialchars((string)($link), ENT_QUOTES, 'UTF-8'); ?>"
   data-fav-desc="<?php echo htmlspecialchars((string)($desc), ENT_QUOTES, 'UTF-8'); ?>"
   data-validated-for-prod="<?php echo htmlspecialchars((string)($validatedForProd), ENT_QUOTES, 'UTF-8'); ?>">
  <div class="rpt-ico rpt-ico-<?php echo $i % 6; ?>">
    <span class="material-icons-outlined"><?php echo htmlspecialchars((string)($iconName), ENT_QUOTES, 'UTF-8'); ?></span>
  </div>
  <span><?php echo htmlspecialchars((string)($title), ENT_QUOTES, 'UTF-8'); ?></span>
  <?php if ($validatedForProd === 'Y') { ?>
      <img src="/gsr/common/images/green-check-mark-circular-64.png"
           class="validation-tick top-report-validation-tick"
           width="64"
           height="64"
           alt="Validated for production"
           title="Validated for production">
  <?php } ?>
  <span class="material-icons-outlined top-report-fav-star "
        title="Add to Favorites">
      star_border
  </span>
</a>
        <?php } ?>
      </div>
    </section>
    <?php } ?>
	<?php
$all_powerbi_reports = array();

foreach ($powerbi_dashboard_groups as $group) {

    if (!empty($group['items'])) {
        $all_powerbi_reports = array_merge($all_powerbi_reports, $group['items']);
    }

}
?>
	<section class="panel-bi" id="powerbi-clearinghouse">

		<div class="sec-hdr pi-head">
			<h2>
				<span class="material-icons-outlined">analytics</span>
				Power BI Reports (May need access)
			</h2>
		</div>

		<?php if (!empty($all_powerbi_reports)) { ?>

			<div class="rpt-grid">

				<?php foreach ($all_powerbi_reports as $powerbi_report) { ?>

					<a class="rpt-card"
					   target="_blank"
					   rel="noopener noreferrer"
					   href="<?php echo htmlspecialchars((string)($powerbi_report['link']), ENT_QUOTES, 'UTF-8'); ?>"
					   data-title="<?php echo htmlspecialchars((string)($powerbi_report['title']), ENT_QUOTES, 'UTF-8'); ?>">

						<div class="rpt-ico">
							<span class="material-icons-outlined">analytics</span>
						</div>

						<span>
							<?php echo htmlspecialchars((string)($powerbi_report['title']), ENT_QUOTES, 'UTF-8'); ?>
						</span>

					</a>

				<?php } ?>

			</div>

		<?php } else { ?>

			<div class="empty">
				No active Power BI Reports reports found.
			</div>

		<?php } ?>

	</section>
    <div class="bottom">
      <div class="panel">
		  <div class="panel-hdr">
			<h3><span class="material-icons-outlined">history</span>Recently Viewed</h3>
			<a class="sec-link" href="javascript:void(0);" id="clearRecentViews">Clear</a>
		  </div>
		  <div class="panel-body" id="recentlyViewedBody"></div>
		</div>
      <div class="panel"><div class="panel-hdr"><h3><span class="material-icons-outlined">bolt</span>Quick Access</h3></div><div class="panel-body">
        
        <a class="ql" href="<?php echo $gsr_base_url.'help'; ?>"><div class="ql-ico" style="background:rgba(0,0,117,.06);color:var(--abbott-indigo)"><span class="material-icons-outlined">support</span></div><div class="ql-text"><strong>Help &amp; Documentation</strong><small>Guides, FAQs, training</small></div><span class="material-icons-outlined ql-arr">arrow_forward</span></a>
        <a class="ql" href="https://abbott.sharepoint.com/sites/GLB-ADD-MyGSS" target="_blank" rel="noopener noreferrer"><div class="ql-ico" style="background:rgba(5,150,105,.07);color:var(--accent-green)"><span class="material-icons-outlined">business_center</span></div><div class="ql-text"><strong>My GSS</strong><small>Global Service Support</small></div><span class="material-icons-outlined ql-arr">arrow_forward</span></a>
      </div></div>
    </div>
  </div>
  <footer class="app-footer"><div class="footer-left"><svg viewBox="0 0 192 30" fill="currentColor" xmlns="http://www.w3.org/2000/svg"><path d="M30.97 .72H0v4.68h29.54c.91 0 1.46.61 1.46 1.51v16.18c0 .9-.55 1.51-1.46 1.51H6.14c-.91 0-1.46-.6-1.46-1.51v-6.59c0-.9.55-1.51 1.46-1.51h20.02v-4.69H4.72C2 10.31 0 12.35 0 15.03v9.54c0 2.67 2 4.72 4.72 4.72h26.27c2.72 0 4.7-2.06 4.7-4.73V5.44C35.69 2.78 33.69.71 30.97.71"/><path d="M56.04 17.44l4.46-11.95h.2l4.33 11.95h-8.99zm7.38-16.93h-4.46L50.08 24.01c-1.3 3.44-2.17 4.41-2.97 5.26v.23h6.33v-.23c-.46-.54-.61-1.24-.61-1.93 0-1.09.39-2.33.76-3.33l1.31-3.5h11.25l1.51 4.16c.31.85.5 1.62.5 2.4 0 .77-.19 1.43-.61 2.2l-.04.23h7.62v-.23c-1.18-1.2-1.83-2.51-2.55-4.45L63.43.5z"/><path d="M87.04 26.44H82.08V3.56h4.77c2.9 0 5.76.89 5.76 4.31 0 3.42-2.94 4.74-5.91 4.74h-2.44v3.05h2.55c3.28 0 7.24.89 7.24 5.37 0 4.1-3.32 5.41-7.02 5.41m3.24-12.29v-.19c4.31-.46 6.86-2.94 6.86-6.77 0-4.68-3.74-6.69-8.92-6.69H76.14v.23c.91 1 1.45 2.32 1.45 4.29v19.95c0 1.97-.54 3.28-1.45 4.29v.23h13c5.64 0 9.49-3.02 9.49-8.08 0-5.06-3.58-6.98-8.35-7.25"/><path d="M110.13 26.44h-4.96V3.56h4.77c2.9 0 5.76.89 5.76 4.31 0 3.42-2.94 4.74-5.91 4.74h-2.44v3.05h2.55c3.28 0 7.24.89 7.24 5.37 0 4.1-3.32 5.41-7.02 5.41m3.24-12.29v-.19c4.31-.46 6.86-2.94 6.86-6.77 0-4.68-3.74-6.69-8.92-6.69H99.22v.23c.92 1 1.45 2.32 1.45 4.29v19.95c0 1.97-.53 3.28-1.45 4.29v.23h13c5.64 0 9.49-3.02 9.49-8.08 0-5.06-3.58-6.98-8.35-7.25"/><path d="M137.44 26.71c-6.16 0-10.03-5.18-10.03-11.71 0-6.53 3.9-11.71 10.03-11.71 6.12 0 10.03 5.18 10.03 11.71 0 6.53-3.87 11.71-10.03 11.71zm0-26.71C128.75 0 122.69 6.46 122.69 15s6.06 15 14.75 15 14.76-6.42 14.76-15S146.13 0 137.44 0z"/><path d="M150.99.5v5.14h.22c.75-1.16 2.12-2.09 5.02-2.09h4.4v21.42c0 1.93-.5 3.29-1.41 4.29v.23h7.32v-.23c-.88-1-1.41-2.36-1.41-4.29V3.56h12.72v21.42c0 1.93-.57 3.29-1.45 4.29v.23h7.4v-.23c-.92-1-1.45-2.36-1.45-4.29V3.56h4.35c2.9 0 4.31.93 5.07 2.09h.23V.5H150.99z"/></svg><span>&copy; 2026 Abbott. All Rights Reserved.</span></div></footer>
</main>
</div>
<script>
(function(){var d=document.getElementById('heroDate');if(d){var n=new Date();d.textContent=n.toLocaleDateString('en-US',{weekday:'long',year:'numeric',month:'long',day:'numeric'})+' \u00b7 '+n.toLocaleTimeString('en-US',{hour:'numeric',minute:'2-digit',timeZoneName:'short'})}})();
document.querySelectorAll('[data-expand]').forEach(function(el){el.addEventListener('click',function(e){e.preventDefault();document.querySelectorAll('.nav-item.expanded').forEach(function(o){if(o!==el)o.classList.remove('expanded')});el.classList.toggle('expanded')})});


</script>
<script>
document.addEventListener('DOMContentLoaded', function () {
  const favoritesBody = document.getElementById('favoritesBody');
  const ajaxUrl = 'gsr_favorites_ajax.php';

  function escapeHTML(str) {
    return String(str || '').replace(/[&<>'"]/g, function (c) {
      return {'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c];
    });
  }

  function loadFavorites() {
    fetch(ajaxUrl + '?action=list')
      .then(res => res.json())
      .then(data => {
          const items = data.items || [];

          window.GSR_FAVORITES = items.map(function(item) {
              return String(item.fav_name || '');
          });

          syncAllFavoriteStars();
          renderFavorites(items);
      });
}

  function renderFavorites(items) {
    const searchData = window.GSR_SEARCH_DATA || [];

    function findReportByName(name) {
        return searchData.find(function (r) {
            return String(r.title || '') === String(name || '');
        }) || {};
    }

    if (!items.length) {
        favoritesBody.innerHTML = `
            <div class="empty">
              No favorites yet. Drag or click reports from the left navigation to pin them here.
            </div>`;
        return;
    }

    favoritesBody.innerHTML = items.map(function (item) {
        const report = findReportByName(item.fav_name);
        const href = report.link || '#';
        const isValidatedForProd = String(report.validated_for_prod || '').toUpperCase() === 'Y';
        const validationTick = isValidatedForProd
            ? `<img src="/gsr/common/images/green-check-mark-circular-64.png"
                    class="validation-tick fav-validation-tick"
                    width="64"
                    height="64"
                    alt="Validated for production"
                    title="Validated for production">`
            : '';

        return `
            <div class="fav-card"
                 data-name="${escapeHTML(item.fav_name)}"
                 data-href="${escapeHTML(href)}"
                 data-validated-for-prod="${isValidatedForProd ? 'Y' : 'N'}">
              <button class="fav-close" title="Remove">×</button>
              <span class="fav-star">★</span>

              <a href="${escapeHTML(href)}" target="_blank" rel="noopener noreferrer">
                <div class="fav-ico">
                  <span class="material-icons-outlined">dashboard</span>
                </div>
                <div class="fav-title-row">
                  <h3>${escapeHTML(item.fav_name)}</h3>
                  ${validationTick}
                </div>
                <p>${escapeHTML(report.desc || 'Global Service Report')}</p>
              </a>
            </div>`;
    }).join('');
}

function updateSidebarStar(name, isFavorite) {
    document.querySelectorAll('.draggable-report').forEach(function (el) {
        if (String(el.dataset.favName || '') !== String(name || '')) {
            return;
        }

        let star = el.querySelector('.fav-icon');

        if (!star) {
            star = document.createElement('span');
            star.className = 'material-icons-outlined fav-icon';
            el.appendChild(star);
        }

        if (isFavorite) {
            star.classList.add('active');
            star.textContent = 'star';
        } else {
            star.classList.remove('active');
            star.textContent = 'star_border';
        }
    });

    document.querySelectorAll('.top-report-card').forEach(function (el) {
        if (String(el.dataset.favName || '') !== String(name || '')) {
            return;
        }

        const star = el.querySelector('.top-report-fav-star');
        if (!star) return;

        if (isFavorite) {
            star.classList.add('active');
            star.textContent = 'star';
            star.title = 'Remove from Favorites';
        } else {
            star.classList.remove('active');
            star.textContent = 'star_border';
            star.title = 'Add to Favorites';
        }
    });
}

function syncAllFavoriteStars() {
    const favoriteSet = new Set((window.GSR_FAVORITES || []).map(function (name) {
        return String(name || '').toLowerCase();
    }));

    document.querySelectorAll('.draggable-report').forEach(function (el) {
        const name = String(el.dataset.favName || '');
        const star = el.querySelector('.fav-icon');
        if (!star) return;
        const active = favoriteSet.has(name.toLowerCase());
        star.classList.toggle('active', active);
        star.textContent = active ? 'star' : 'star_border';
    });

    document.querySelectorAll('.top-report-card').forEach(function (el) {
        const name = String(el.dataset.favName || '');
        const star = el.querySelector('.top-report-fav-star');
        if (!star) return;
        const active = favoriteSet.has(name.toLowerCase());
        star.classList.toggle('active', active);
        star.textContent = active ? 'star' : 'star_border';
        star.title = active ? 'Remove from Favorites' : 'Add to Favorites';
    });
}

function addFavorite(item) {
    if (!item.name || !item.href) return;

    const formData = new FormData();
    formData.append('action', 'add');
    formData.append('name', item.name);
    formData.append('href', item.href);
    formData.append('desc', item.desc || '');

    fetch(ajaxUrl, {
        method: 'POST',
        body: formData
    })
    .then(res => res.json())
    .then(data => {
        if (data.success) {
            updateSidebarStar(item.name, true);
            loadFavorites();
        }
    });
}

  function removeFavorite(name, href) {
    const formData = new FormData();
    formData.append('action', 'remove');
    formData.append('name', name);
    formData.append('href', href);

    fetch(ajaxUrl, {
        method: 'POST',
        body: formData
    })
    .then(res => res.json())
    .then(data => {
        if (data.success) {
            updateSidebarStar(name, false);
            loadFavorites();
        }
    });
}
window.gsrAddFavorite = addFavorite;
window.gsrRemoveFavorite = removeFavorite;
window.gsrLoadFavorites = loadFavorites;

  document.querySelectorAll('.draggable-report').forEach(function (item) {
    item.addEventListener('dragstart', function (e) {
      const favData = {
        name: this.dataset.favName,
        href: this.dataset.favHref,
        desc: this.dataset.favDesc
      };

      e.dataTransfer.setData('text/plain', JSON.stringify(favData));
    });

    item.addEventListener('click', function (e) {
    if (!e.target.classList.contains('fav-icon')) {
        return;
    }

    e.preventDefault();
    e.stopPropagation();

    const isActive = e.target.classList.contains('active');

    if (isActive) {
        removeFavorite(this.dataset.favName, this.dataset.favHref);
    } else {
        addFavorite({
            name: this.dataset.favName,
            href: this.dataset.favHref,
            desc: this.dataset.favDesc
        });
    }
	});
  });

  document.querySelectorAll('.top-report-card').forEach(function (item) {
    item.addEventListener('click', function (e) {
        if (!e.target.classList.contains('top-report-fav-star')) {
            return;
        }

        e.preventDefault();
        e.stopPropagation();

        const star = e.target;
        const favItem = {
            name: this.dataset.favName,
            href: this.dataset.favHref,
            desc: this.dataset.favDesc || ''
        };

        if (star.classList.contains('active')) {
            removeFavorite(favItem.name, favItem.href);
        } else {
            addFavorite(favItem);
        }
    });
  });

  favoritesBody.addEventListener('dragover', function (e) {
    e.preventDefault();
  });

  favoritesBody.addEventListener('drop', function (e) {
    e.preventDefault();

    try {
      const data = JSON.parse(e.dataTransfer.getData('text/plain'));
      addFavorite(data);
    } catch (err) {}
  });

  favoritesBody.addEventListener('click', function (e) {
    if (!e.target.classList.contains('fav-close')) return;

    e.preventDefault();
    e.stopPropagation();

    const card = e.target.closest('.fav-card');
    removeFavorite(card.dataset.name, card.dataset.href);
  });

  loadFavorites();
});
</script>
<script>
document.addEventListener('DOMContentLoaded', function () {
  const headerInput = document.getElementById('globalSearchInput');
  const searchBox = document.getElementById('globalSearchBox');
  const modal = document.getElementById('searchModal');
  const overlay = document.getElementById('searchModalOverlay');
  const body = document.getElementById('searchModalBody');
  const sidebar = document.getElementById('sidebar');
  const sideBackdrop = document.getElementById('sideBackdrop');
  const data = window.GSR_SEARCH_DATA || [];

  function escapeHTML(str) {
    return String(str || '').replace(/[&<>'"]/g, function (c) {
      return {'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c];
    });
  }

  function isMobile() {
    return window.innerWidth <= 768;
  }

  function setModalPosition() {
    if (!modal || !searchBox) return;

    if (isMobile()) {
      modal.style.left = '12px';
      modal.style.top = document.querySelector('.top-bar').offsetHeight + 'px';
      modal.style.width = 'calc(100vw - 24px)';
      return;
    }

    const rect = searchBox.getBoundingClientRect();
    modal.style.left = rect.left + 'px';
    modal.style.top = rect.bottom + 'px';
    modal.style.width = rect.width + 'px';
  }

  function normalizeFavName(str) {
    return String(str || '').toLowerCase();
}

function isFavoriteReport(title) {
    const favs = window.GSR_FAVORITES || [];
    return favs.some(function (fav) {
        return normalizeFavName(fav) === normalizeFavName(title);
    });
}

function renderResults() {
    const q = String(headerInput.value || '').trim().toLowerCase();

    if (!q) {
        body.innerHTML = '<div class="search-empty">Start typing to search reports.</div>';
        return;
    }

    /*
     * Business abbreviation / keyword aliases for Global Search only.
     * These aliases DO NOT change Top-58 logic, sidebar population,
     * database data, favorites, Power BI, KPI cards or cache behavior.
     *
     * A keyword can map to one or more actual report search terms.
     */
    const searchAliases = {
        'cpb': ['cost per box'],
        'cos': ['cost of service'],
        'mttr': ['mean time to repair'],
        'call center': ['helios telephony', 'remote support'],
        'c360': ['c360', 'c 360', 'customer 360', 'customer360']
    };

    /* Always search the exact text entered by the user. */
    const searchTerms = [q];

    /*
     * Expand aliases.
     * Examples:
     *   cpb         -> cost per box
     *   call        -> helios telephony + remote support
     *   call center -> helios telephony + remote support
     */
    Object.keys(searchAliases).forEach(function (alias) {
        const aliasMatches =
            q === alias ||
            q.includes(alias) ||
            (q.length >= 4 && alias.includes(q));

        if (!aliasMatches) {
            return;
        }

        searchAliases[alias].forEach(function (term) {
            const normalizedTerm = String(term || '').toLowerCase();
            if (normalizedTerm && !searchTerms.includes(normalizedTerm)) {
                searchTerms.push(normalizedTerm);
            }
        });
    });

    const validatedSearch = (q === 'validated' || q === 'validated reports');
    const powerBISearch = (
        q === 'powerbi' ||
        q === 'power bi' ||
        q === 'power bi reports'
    );

    let results = data.filter(function (item) {
        if (validatedSearch) {
            return String(item.validated_for_prod || '').toUpperCase() === 'Y';
        }

        if (powerBISearch) {
            return String(item.type || '').toLowerCase() === 'power bi reports';
        }

        const searchableText = [
            item.title || '',
            item.desc || '',
            item.type || '',
            item.keywords || ''
        ].join(' ').toLowerCase();

        return searchTerms.some(function (term) {
            return searchableText.includes(String(term || '').toLowerCase());
        });
    });

    /* Normal searches keep the existing result limit.
       Validated and Power BI keyword searches intentionally show all matching reports. */
    if (!validatedSearch && !powerBISearch) {
        results = results.slice(0, 20);
    }

    if (!results.length) {
        body.innerHTML = '<div class="search-empty">No results found.</div>';
        return;
    }

    body.innerHTML = `
      <div class="search-section">
        <div class="search-section-title">Reports</div>
        ${results.map(function (item) {
          const validationTick = String(item.validated_for_prod || '').toUpperCase() === 'Y'
              ? `<img src="/gsr/common/images/green-check-mark-circular-64.png"
                      class="search-validation-tick"
                      width="18"
                      height="18"
                      alt="Validated for production"
                      title="Validated for production">`
              : '';

          const favStar = (item.favorite_enabled === false) ? '' : `
          <span class="material-icons-outlined search-fav-star ${isFavoriteReport(item.title) ? 'active' : ''}"
                data-name="${escapeHTML(item.title)}"
                data-href="${escapeHTML(item.link)}"
                data-desc="${escapeHTML(item.desc || '')}">
            ${isFavoriteReport(item.title) ? 'star' : 'star_border'}
          </span>`;

          return `
            <a class="search-item" href="${escapeHTML(item.link)}" target="_blank" rel="noopener noreferrer">
              <div class="search-thumb">
                <span class="material-icons-outlined">${escapeHTML(item.icon || 'description')}</span>
              </div>

              <div class="search-info">
                <div class="search-title-row">
                  <div class="search-title">${escapeHTML(item.title)}</div>
                  ${validationTick}
                  ${favStar}
                </div>
                <div class="search-desc">${escapeHTML(item.desc || 'Global Service Report')}</div>
              </div>
            </a>`;
        }).join('')}
      </div>`;
}
body.addEventListener('click', function(e) {
    if (!e.target.classList.contains('search-fav-star')) {
        return;
    }

    e.preventDefault();
    e.stopPropagation();

    const star = e.target;
    const isActive = star.classList.contains('active');

    const item = {
        name: star.dataset.name,
        href: star.dataset.href,
        desc: star.dataset.desc || ''
    };

    if (isActive) {
        window.gsrRemoveFavorite(item.name, item.href);
        star.classList.remove('active');
        star.textContent = 'star_border';
    } else {
        window.gsrAddFavorite(item);
        star.classList.add('active');
        star.textContent = 'star';

        if (!window.GSR_FAVORITES.includes(item.name)) {
            window.GSR_FAVORITES.push(item.name);
        }
    }
});
  function openModal() {
    setModalPosition();
    modal.classList.add('active');
    overlay.classList.add('active');
    renderResults();
  }

  function closeModal() {
    modal.classList.remove('active');
    overlay.classList.remove('active');
  }

  headerInput.addEventListener('input', function () {
    if (headerInput.value) openModal();
    else closeModal();
  });

  headerInput.addEventListener('focus', function () {
    if (headerInput.value) openModal();
  });

  document.addEventListener('click', function (e) {
    if (!modal.contains(e.target) && !searchBox.contains(e.target)) {
      closeModal();
    }
  });

  overlay.addEventListener('click', closeModal);
  window.addEventListener('resize', setModalPosition);
  window.addEventListener('scroll', setModalPosition, true);

  document.addEventListener('keydown', function (e) {
    if (e.key === 'Escape') {
      closeModal();
      if (sidebar) sidebar.classList.remove('open');
    }
  });

  if (sideBackdrop) {
    sideBackdrop.addEventListener('click', function () {
      sidebar.classList.remove('open');
    });
  }
});
</script>
<script>
document.addEventListener('DOMContentLoaded', function () {

    const btn = document.getElementById('profileBtn');
    const popup = document.getElementById('profileDropdown');
    const wrap = document.getElementById('profileWrap');

    if (!btn || !popup) return;

    btn.addEventListener('click', function (e) {
        e.preventDefault();
        popup.classList.toggle('active');
    });

    document.addEventListener('click', function (e) {
        if (!wrap.contains(e.target)) {
            popup.classList.remove('active');
        }
    });
});
</script>
<script>
document.addEventListener('DOMContentLoaded', function () {
    const sidebar = document.getElementById('sidebar');
    const toggleBtn = document.getElementById('sidebarToggle');
    const toggleIcon = document.getElementById('sidebarToggleIcon');

    if (!sidebar || !toggleBtn || !toggleIcon) return;

    toggleBtn.addEventListener('click', function () {
        sidebar.classList.toggle('collapsed');

        if (sidebar.classList.contains('collapsed')) {
            toggleIcon.textContent = 'chevron_right';
        } else {
            toggleIcon.textContent = 'chevron_left';
        }
    });
});
</script>
<script>

document.addEventListener("DOMContentLoaded", function () {

    const card = document.getElementById("powerbiReportCard");

    if(card){

        card.addEventListener("click", function(){

            document.getElementById("powerbi-clearinghouse")
                .scrollIntoView({
                    behavior: "smooth",
                    block: "start"
                });

        });

    }

});

</script>
<script>
document.addEventListener('DOMContentLoaded', function () {
    const recentBody = document.getElementById('recentlyViewedBody');
    const clearBtn = document.getElementById('clearRecentViews');
    const storageKey = 'GSR_RECENTLY_VIEWED';

    function escapeHTML(str) {
        return String(str || '').replace(/[&<>'"]/g, function (c) {
            return {'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c];
        });
    }

    function timeAgo(time) {
        const diff = Math.floor((Date.now() - time) / 1000);

        if (diff < 60) return 'Just now';
        if (diff < 3600) return Math.floor(diff / 60) + 'm ago';
        if (diff < 86400) return Math.floor(diff / 3600) + 'h ago';
        if (diff < 172800) return 'Yesterday';

        return Math.floor(diff / 86400) + 'd ago';
    }

    function getRecentViews() {
        try {
            return JSON.parse(localStorage.getItem(storageKey)) || [];
        } catch (e) {
            return [];
        }
    }

    function saveRecentViews(items) {
        localStorage.setItem(storageKey, JSON.stringify(items));
    }

    function addRecentView(item) {
        if (!item.title || !item.href || item.href === '#') return;

        let items = getRecentViews();

        items = items.filter(function (r) {
            return r.title !== item.title;
        });

        items.unshift({
            title: item.title,
            href: item.href,
            desc: item.desc || 'Global Service Report',
            icon: item.icon || 'dashboard',
            time: Date.now()
        });

        items = items.slice(0, 3);
        saveRecentViews(items);
        renderRecentViews();
    }

    function renderRecentViews() {
        const items = getRecentViews();

        if (!items.length) {
            recentBody.innerHTML = `
                <div class="empty" style="margin:12px;">
                    No recently viewed reports yet.
                </div>`;
            return;
        }

        recentBody.innerHTML = items.map(function (item, index) {
            const colorClass = ['c1', 'c2', 'c3'][index % 3];

            return `
                <a class="act-item" href="${escapeHTML(item.href)}" target="_blank" rel="noopener noreferrer">
                    <div class="act-dot ${colorClass}">
                        <span class="material-icons-outlined" style="font-size:15px">
                            ${escapeHTML(item.icon)}
                        </span>
                    </div>
                    <div class="act-text">
                        <strong>${escapeHTML(item.title)}</strong>
                        <small>${escapeHTML(item.desc)}</small>
                    </div>
                    <span class="act-time">${timeAgo(item.time)}</span>
                </a>`;
        }).join('');
    }

    document.querySelectorAll('.draggable-report, .rpt-card, .ql').forEach(function (el) {

    el.addEventListener('click', function () {

        addRecentView({
            title: this.dataset.favName ||
                   this.dataset.title ||
                   (this.querySelector('strong')
                        ? this.querySelector('strong').textContent
                        : this.querySelector('span:last-child').textContent),

            href: this.dataset.favHref || this.getAttribute('href'),

            desc: this.dataset.favDesc || 'Global Service Report',

            icon: 'dashboard'
        });

    });

});

    clearBtn.addEventListener('click', function () {
        localStorage.removeItem(storageKey);
        renderRecentViews();
    });

    renderRecentViews();
});
</script>
</body>
</html>