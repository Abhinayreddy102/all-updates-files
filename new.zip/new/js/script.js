(function () {
    var dataNode = document.getElementById('gsrSearchData');

    try {
        window.GSR_SEARCH_DATA = dataNode ? JSON.parse(dataNode.textContent || '[]') : [];
    } catch (e) {
        window.GSR_SEARCH_DATA = [];
    }

    window.GSR_FAVORITES = [];
}());
(function(){var d=document.getElementById('heroDate');if(d){var n=new Date();d.textContent=n.toLocaleDateString('en-US',{weekday:'long',year:'numeric',month:'long',day:'numeric'})+' \u00b7 '+n.toLocaleTimeString('en-US',{hour:'numeric',minute:'2-digit',timeZoneName:'short'})}})();
document.querySelectorAll('[data-expand]').forEach(function(el){el.addEventListener('click',function(e){e.preventDefault();document.querySelectorAll('.nav-item.expanded').forEach(function(o){if(o!==el)o.classList.remove('expanded')});el.classList.toggle('expanded')})});

document.addEventListener('DOMContentLoaded', function () {
  const favoritesBody = document.getElementById('favoritesBody');
  const ajaxUrl = 'gsr_favorites_ajax.php';

  function escapeHTML(str) {
    return String(str || '').replace(/[&<>'"]/g, function (c) {
      return {'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c];
    });
  }

  function loadFavorites() {
    fetch(ajaxUrl + '?action=list')
      .then(res => res.json())
      .then(data => {
          const items = data.items || [];

          window.GSR_FAVORITES = items.map(function(item) {
              return String(item.fav_name || '');
          });

          syncAllFavoriteStars();
          renderFavorites(items);
      });
}

  function renderFavorites(items) {
    const searchData = window.GSR_SEARCH_DATA || [];

    function findReportByName(name) {
        return searchData.find(function (r) {
            return String(r.title || '') === String(name || '');
        }) || {};
    }

    if (!items.length) {
        favoritesBody.innerHTML = `
            <div class="empty">
              No favorites yet. Drag or click reports from the left navigation to pin them here.
            </div>`;
        return;
    }

    favoritesBody.innerHTML = items.map(function (item) {
        const report = findReportByName(item.fav_name);
        const href = report.link || '#';
        const isValidatedForProd = String(report.validated_for_prod || '').toUpperCase() === 'Y';
        const validationTick = isValidatedForProd
            ? `<img src="/gsr/common/images/green-check-mark-circular-64.png"
                    class="validation-tick fav-validation-tick"
                    width="64"
                    height="64"
                    alt="Validated for production"
                    title="Validated for production">`
            : '';

        return `
            <div class="fav-card"
                 data-name="${escapeHTML(item.fav_name)}"
                 data-href="${escapeHTML(href)}"
                 data-validated-for-prod="${isValidatedForProd ? 'Y' : 'N'}">
              <button class="fav-close" title="Remove">×</button>
              <span class="fav-star">★</span>

              <a href="${escapeHTML(href)}" target="_blank" rel="noopener noreferrer">
                <div class="fav-ico">
                  <span class="material-icons-outlined">dashboard</span>
                </div>
                <div class="fav-title-row">
                  <h3>${escapeHTML(item.fav_name)}</h3>
                  ${validationTick}
                </div>
                <p>${escapeHTML(report.desc || 'Global Service Report')}</p>
              </a>
            </div>`;
    }).join('');
}

function updateSidebarStar(name, isFavorite) {
    document.querySelectorAll('.draggable-report').forEach(function (el) {
        if (String(el.dataset.favName || '') !== String(name || '')) {
            return;
        }

        let star = el.querySelector('.fav-icon');

        if (!star) {
            star = document.createElement('span');
            star.className = 'material-icons-outlined fav-icon';
            el.appendChild(star);
        }

        if (isFavorite) {
            star.classList.add('active');
            star.textContent = 'star';
        } else {
            star.classList.remove('active');
            star.textContent = 'star_border';
        }
    });

    document.querySelectorAll('.top-report-card').forEach(function (el) {
        if (String(el.dataset.favName || '') !== String(name || '')) {
            return;
        }

        const star = el.querySelector('.top-report-fav-star');
        if (!star) return;

        if (isFavorite) {
            star.classList.add('active');
            star.textContent = 'star';
            star.title = 'Remove from Favorites';
        } else {
            star.classList.remove('active');
            star.textContent = 'star_border';
            star.title = 'Add to Favorites';
        }
    });
}

function syncAllFavoriteStars() {
    const favoriteSet = new Set((window.GSR_FAVORITES || []).map(function (name) {
        return String(name || '').toLowerCase();
    }));

    document.querySelectorAll('.draggable-report').forEach(function (el) {
        const name = String(el.dataset.favName || '');
        const star = el.querySelector('.fav-icon');
        if (!star) return;
        const active = favoriteSet.has(name.toLowerCase());
        star.classList.toggle('active', active);
        star.textContent = active ? 'star' : 'star_border';
    });

    document.querySelectorAll('.top-report-card').forEach(function (el) {
        const name = String(el.dataset.favName || '');
        const star = el.querySelector('.top-report-fav-star');
        if (!star) return;
        const active = favoriteSet.has(name.toLowerCase());
        star.classList.toggle('active', active);
        star.textContent = active ? 'star' : 'star_border';
        star.title = active ? 'Remove from Favorites' : 'Add to Favorites';
    });
}

function addFavorite(item) {
    if (!item.name || !item.href) return;

    const formData = new FormData();
    formData.append('action', 'add');
    formData.append('name', item.name);
    formData.append('href', item.href);
    formData.append('desc', item.desc || '');

    fetch(ajaxUrl, {
        method: 'POST',
        body: formData
    })
    .then(res => res.json())
    .then(data => {
        if (data.success) {
            updateSidebarStar(item.name, true);
            loadFavorites();
        }
    });
}

  function removeFavorite(name, href) {
    const formData = new FormData();
    formData.append('action', 'remove');
    formData.append('name', name);
    formData.append('href', href);

    fetch(ajaxUrl, {
        method: 'POST',
        body: formData
    })
    .then(res => res.json())
    .then(data => {
        if (data.success) {
            updateSidebarStar(name, false);
            loadFavorites();
        }
    });
}
window.gsrAddFavorite = addFavorite;
window.gsrRemoveFavorite = removeFavorite;
window.gsrLoadFavorites = loadFavorites;

  document.querySelectorAll('.draggable-report').forEach(function (item) {
    item.addEventListener('dragstart', function (e) {
      const favData = {
        name: this.dataset.favName,
        href: this.dataset.favHref,
        desc: this.dataset.favDesc
      };

      e.dataTransfer.setData('text/plain', JSON.stringify(favData));
    });

    item.addEventListener('click', function (e) {
    if (!e.target.classList.contains('fav-icon')) {
        return;
    }

    e.preventDefault();
    e.stopPropagation();

    const isActive = e.target.classList.contains('active');

    if (isActive) {
        removeFavorite(this.dataset.favName, this.dataset.favHref);
    } else {
        addFavorite({
            name: this.dataset.favName,
            href: this.dataset.favHref,
            desc: this.dataset.favDesc
        });
    }
	});
  });

  document.querySelectorAll('.top-report-card').forEach(function (item) {
    item.addEventListener('click', function (e) {
        if (!e.target.classList.contains('top-report-fav-star')) {
            return;
        }

        e.preventDefault();
        e.stopPropagation();

        const star = e.target;
        const favItem = {
            name: this.dataset.favName,
            href: this.dataset.favHref,
            desc: this.dataset.favDesc || ''
        };

        if (star.classList.contains('active')) {
            removeFavorite(favItem.name, favItem.href);
        } else {
            addFavorite(favItem);
        }
    });
  });

  favoritesBody.addEventListener('dragover', function (e) {
    e.preventDefault();
  });

  favoritesBody.addEventListener('drop', function (e) {
    e.preventDefault();

    try {
      const data = JSON.parse(e.dataTransfer.getData('text/plain'));
      addFavorite(data);
    } catch (err) {}
  });

  favoritesBody.addEventListener('click', function (e) {
    if (!e.target.classList.contains('fav-close')) return;

    e.preventDefault();
    e.stopPropagation();

    const card = e.target.closest('.fav-card');
    removeFavorite(card.dataset.name, card.dataset.href);
  });

  loadFavorites();
});

document.addEventListener('DOMContentLoaded', function () {
  const headerInput = document.getElementById('globalSearchInput');
  const searchBox = document.getElementById('globalSearchBox');
  const modal = document.getElementById('searchModal');
  const overlay = document.getElementById('searchModalOverlay');
  const body = document.getElementById('searchModalBody');
  const sidebar = document.getElementById('sidebar');
  const sideBackdrop = document.getElementById('sideBackdrop');
  const data = window.GSR_SEARCH_DATA || [];

  function escapeHTML(str) {
    return String(str || '').replace(/[&<>'"]/g, function (c) {
      return {'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c];
    });
  }

  function isMobile() {
    return window.innerWidth <= 768;
  }

  function setModalPosition() {
    if (!modal || !searchBox) return;

    if (isMobile()) {
      modal.style.left = '12px';
      modal.style.top = document.querySelector('.top-bar').offsetHeight + 'px';
      modal.style.width = 'calc(100vw - 24px)';
      return;
    }

    const rect = searchBox.getBoundingClientRect();
    modal.style.left = rect.left + 'px';
    modal.style.top = rect.bottom + 'px';
    modal.style.width = rect.width + 'px';
  }

  function normalizeFavName(str) {
    return String(str || '').toLowerCase();
}

function isFavoriteReport(title) {
    const favs = window.GSR_FAVORITES || [];
    return favs.some(function (fav) {
        return normalizeFavName(fav) === normalizeFavName(title);
    });
}

function renderResults() {
    const q = String(headerInput.value || '').trim().toLowerCase();

    if (!q) {
        body.innerHTML = '<div class="search-empty">Start typing to search reports.</div>';
        return;
    }

    /*
     * Business abbreviation / keyword aliases for Global Search only.
     * These aliases DO NOT change Top-58 logic, sidebar population,
     * database data, favorites, Power BI, KPI cards or cache behavior.
     *
     * A keyword can map to one or more actual report search terms.
     */
    const searchAliases = {
        'cpb': ['cost per box'],
        'cos': ['cost of service'],
        'mttr': ['mean time to repair'],
        'call center': ['helios telephony', 'remote support'],
        'c360': ['c360', 'c 360', 'customer 360', 'customer360']
    };

    /* Always search the exact text entered by the user. */
    const searchTerms = [q];

    /*
     * Expand aliases.
     * Examples:
     *   cpb         -> cost per box
     *   call        -> helios telephony + remote support
     *   call center -> helios telephony + remote support
     */
    Object.keys(searchAliases).forEach(function (alias) {
        const aliasMatches =
            q === alias ||
            q.includes(alias) ||
            (q.length >= 2 && alias.startsWith(q));

        if (!aliasMatches) {
            return;
        }

        searchAliases[alias].forEach(function (term) {
            const normalizedTerm = String(term || '').toLowerCase();
            if (normalizedTerm && !searchTerms.includes(normalizedTerm)) {
                searchTerms.push(normalizedTerm);
            }
        });
    });

    const validatedSearch =
        q.length >= 3 &&
        (
            'validated'.startsWith(q) ||
            'validator'.startsWith(q) ||
            'validated reports'.startsWith(q)
        );

    const powerBISearch =
        q.length >= 3 &&
        (
            'powerbi'.startsWith(q.replace(/\s+/g, '')) ||
            'power bi'.startsWith(q) ||
            'power bi reports'.startsWith(q)
        );

    let results = data.filter(function (item) {
        if (validatedSearch) {
            return String(item.validated_for_prod || '').toUpperCase() === 'Y';
        }

        if (powerBISearch) {
            return String(item.type || '').toLowerCase() === 'power bi reports';
        }

        const searchableText = [
            item.title || '',
            item.desc || '',
            item.type || '',
            item.keywords || ''
        ].join(' ').toLowerCase();

        return searchTerms.some(function (term) {
            return searchableText.includes(String(term || '').toLowerCase());
        });
    });

    /* Normal searches keep the existing result limit.
       Validated and Power BI keyword searches intentionally show all matching reports. */
    if (!validatedSearch && !powerBISearch) {
        results = results.slice(0, 20);
    }

    if (!results.length) {
        body.innerHTML = '<div class="search-empty">No results found.</div>';
        return;
    }

    body.innerHTML = `
      <div class="search-section">
        <div class="search-section-title">Reports</div>
        ${results.map(function (item) {
          const validationTick = String(item.validated_for_prod || '').toUpperCase() === 'Y'
              ? `<img src="/gsr/common/images/green-check-mark-circular-64.png"
                      class="search-validation-tick"
                      width="18"
                      height="18"
                      alt="Validated for production"
                      title="Validated for production">`
              : '';

          const favStar = (item.favorite_enabled === false) ? '' : `
          <span class="material-icons-outlined search-fav-star ${isFavoriteReport(item.title) ? 'active' : ''}"
                data-name="${escapeHTML(item.title)}"
                data-href="${escapeHTML(item.link)}"
                data-desc="${escapeHTML(item.desc || '')}">
            ${isFavoriteReport(item.title) ? 'star' : 'star_border'}
          </span>`;

          return `
            <a class="search-item" href="${escapeHTML(item.link)}" target="_blank" rel="noopener noreferrer">
              <div class="search-thumb">
                <span class="material-icons-outlined">${escapeHTML(item.icon || 'description')}</span>
              </div>

              <div class="search-info">
                <div class="search-title-row">
                  <div class="search-title">${escapeHTML(item.title)}</div>
                  ${validationTick}
                  ${favStar}
                </div>
                <div class="search-desc">${escapeHTML(item.desc || 'Global Service Report')}</div>
              </div>
            </a>`;
        }).join('')}
      </div>`;
}
body.addEventListener('click', function(e) {
    if (!e.target.classList.contains('search-fav-star')) {
        return;
    }

    e.preventDefault();
    e.stopPropagation();

    const star = e.target;
    const isActive = star.classList.contains('active');

    const item = {
        name: star.dataset.name,
        href: star.dataset.href,
        desc: star.dataset.desc || ''
    };

    if (isActive) {
        window.gsrRemoveFavorite(item.name, item.href);
        star.classList.remove('active');
        star.textContent = 'star_border';
    } else {
        window.gsrAddFavorite(item);
        star.classList.add('active');
        star.textContent = 'star';

        if (!window.GSR_FAVORITES.includes(item.name)) {
            window.GSR_FAVORITES.push(item.name);
        }
    }
});
  function openModal() {
    setModalPosition();
    modal.classList.add('active');
    overlay.classList.add('active');
    renderResults();
  }

  function closeModal() {
    modal.classList.remove('active');
    overlay.classList.remove('active');
  }

  headerInput.addEventListener('input', function () {
    if (headerInput.value) openModal();
    else closeModal();
  });

  headerInput.addEventListener('focus', function () {
    if (headerInput.value) openModal();
  });

  document.addEventListener('click', function (e) {
    if (!modal.contains(e.target) && !searchBox.contains(e.target)) {
      closeModal();
    }
  });

  overlay.addEventListener('click', closeModal);
  window.addEventListener('resize', setModalPosition);
  window.addEventListener('scroll', setModalPosition, true);

  document.addEventListener('keydown', function (e) {
    if (e.key === 'Escape') {
      closeModal();
      if (sidebar) sidebar.classList.remove('open');
    }
  });

  if (sideBackdrop) {
    sideBackdrop.addEventListener('click', function () {
      sidebar.classList.remove('open');
    });
  }
});

document.addEventListener('DOMContentLoaded', function () {

    const btn = document.getElementById('profileBtn');
    const popup = document.getElementById('profileDropdown');
    const wrap = document.getElementById('profileWrap');

    if (!btn || !popup) return;

    btn.addEventListener('click', function (e) {
        e.preventDefault();
        popup.classList.toggle('active');
    });

    document.addEventListener('click', function (e) {
        if (!wrap.contains(e.target)) {
            popup.classList.remove('active');
        }
    });
});

document.addEventListener('DOMContentLoaded', function () {
    const sidebar = document.getElementById('sidebar');
    const toggleBtn = document.getElementById('sidebarToggle');
    const toggleIcon = document.getElementById('sidebarToggleIcon');

    if (!sidebar || !toggleBtn || !toggleIcon) return;

    toggleBtn.addEventListener('click', function () {
        sidebar.classList.toggle('collapsed');

        if (sidebar.classList.contains('collapsed')) {
            toggleIcon.textContent = 'chevron_right';
        } else {
            toggleIcon.textContent = 'chevron_left';
        }
    });
});

document.addEventListener("DOMContentLoaded", function () {

    const card = document.getElementById("powerbiReportCard");

    if(card){

        card.addEventListener("click", function(){

            document.getElementById("powerbi-clearinghouse")
                .scrollIntoView({
                    behavior: "smooth",
                    block: "start"
                });

        });

    }

});

document.addEventListener('DOMContentLoaded', function () {
    const recentBody = document.getElementById('recentlyViewedBody');
    const clearBtn = document.getElementById('clearRecentViews');
    const storageKey = 'GSR_RECENTLY_VIEWED';

    function escapeHTML(str) {
        return String(str || '').replace(/[&<>'"]/g, function (c) {
            return {'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c];
        });
    }

    function timeAgo(time) {
        const diff = Math.floor((Date.now() - time) / 1000);

        if (diff < 60) return 'Just now';
        if (diff < 3600) return Math.floor(diff / 60) + 'm ago';
        if (diff < 86400) return Math.floor(diff / 3600) + 'h ago';
        if (diff < 172800) return 'Yesterday';

        return Math.floor(diff / 86400) + 'd ago';
    }

    function getRecentViews() {
        try {
            return JSON.parse(localStorage.getItem(storageKey)) || [];
        } catch (e) {
            return [];
        }
    }

    function saveRecentViews(items) {
        localStorage.setItem(storageKey, JSON.stringify(items));
    }

    function addRecentView(item) {
        if (!item.title || !item.href || item.href === '#') return;

        let items = getRecentViews();

        items = items.filter(function (r) {
            return r.title !== item.title;
        });

        items.unshift({
            title: item.title,
            href: item.href,
            desc: item.desc || 'Global Service Report',
            icon: item.icon || 'dashboard',
            time: Date.now()
        });

        items = items.slice(0, 3);
        saveRecentViews(items);
        renderRecentViews();
    }

    function renderRecentViews() {
        const items = getRecentViews();

        if (!items.length) {
            recentBody.innerHTML = `
                <div class="empty" style="margin:12px;">
                    No recently viewed reports yet.
                </div>`;
            return;
        }

        recentBody.innerHTML = items.map(function (item, index) {
            const colorClass = ['c1', 'c2', 'c3'][index % 3];

            return `
                <a class="act-item" href="${escapeHTML(item.href)}" target="_blank" rel="noopener noreferrer">
                    <div class="act-dot ${colorClass}">
                        <span class="material-icons-outlined" style="font-size:15px">
                            ${escapeHTML(item.icon)}
                        </span>
                    </div>
                    <div class="act-text">
                        <strong>${escapeHTML(item.title)}</strong>
                        <small>${escapeHTML(item.desc)}</small>
                    </div>
                    <span class="act-time">${timeAgo(item.time)}</span>
                </a>`;
        }).join('');
    }

    document.querySelectorAll('.draggable-report, .rpt-card, .ql').forEach(function (el) {

    el.addEventListener('click', function () {

        addRecentView({
            title: this.dataset.favName ||
                   this.dataset.title ||
                   (this.querySelector('strong')
                        ? this.querySelector('strong').textContent
                        : this.querySelector('span:last-child').textContent),

            href: this.dataset.favHref || this.getAttribute('href'),

            desc: this.dataset.favDesc || 'Global Service Report',

            icon: 'dashboard'
        });

    });

});

    clearBtn.addEventListener('click', function () {
        localStorage.removeItem(storageKey);
        renderRecentViews();
    });

    renderRecentViews();
});