<?php
/** GSR Dashboard */
require_once 'gsr_environment.php';
require_once(GSR_DOCUMENT_ROOT . '/gsr/common/class/gsr_sqlsrv_db_class.php');
require_once __DIR__ . '/class/gsr_dashboard_class.php';
$dashboard_db = new gsr_dashboard_class();



/* Shared dashboard cache */
function gsrDashboardCacheDirectory()
{
    $cache_dir = rtrim(sys_get_temp_dir(), DIRECTORY_SEPARATOR)
        . DIRECTORY_SEPARATOR . 'gsr_dashboard_cache';

    if (!is_dir($cache_dir)) {
        @mkdir($cache_dir, 0770, true);
    }

    return $cache_dir;
}

function gsrDashboardCacheFile($key)
{
    $safe_key = preg_replace('/[^A-Za-z0-9_\-]/', '_', (string)$key);
    return gsrDashboardCacheDirectory() . DIRECTORY_SEPARATOR . $safe_key . '.cache';
}

function gsrDashboardCacheGet($key, $ttl_seconds)
{
    $cache_file = gsrDashboardCacheFile($key);

    if (!is_file($cache_file) || !is_readable($cache_file)) {
        return false;
    }

    $modified_time = @filemtime($cache_file);
    if ($modified_time === false || (time() - $modified_time) > (int)$ttl_seconds) {
        @unlink($cache_file);
        return false;
    }

    $cache_contents = @file_get_contents($cache_file);
    if ($cache_contents === false || $cache_contents === '') {
        return false;
    }

    $cache_data = @unserialize($cache_contents, array('allowed_classes' => false));

    return is_array($cache_data) ? $cache_data : false;
}

function gsrDashboardCacheSet($key, array $data)
{
    $cache_file = gsrDashboardCacheFile($key);
    $temporary_file = $cache_file . '.' . getmypid() . '.tmp';
    $serialized_data = serialize($data);

    if (@file_put_contents($temporary_file, $serialized_data, LOCK_EX) === false) {
        return false;
    }

    if (!@rename($temporary_file, $cache_file)) {
        @unlink($temporary_file);
        return false;
    }

    return true;
}
$logout_url = 'logout.php';
$display_name = $_SESSION['azure_auth_LastName'] . ', ' . $_SESSION['azure_auth_FirstName'];

$user_initial = substr(ucfirst($display_name), 0, 1);


/* Switch to classic view */

function gsrExperienceBaseUrl()
{
    $is_https =
        (!empty($_SERVER['HTTPS']) && strtolower((string)$_SERVER['HTTPS']) !== 'off')
        || (!empty($_SERVER['SERVER_PORT']) && (int)$_SERVER['SERVER_PORT'] === 443)
        || (!empty($_SERVER['HTTP_X_FORWARDED_PROTO'])
            && strtolower(trim(explode(',', (string)$_SERVER['HTTP_X_FORWARDED_PROTO'])[0])) === 'https');

    $protocol = $is_https ? 'https' : 'http';

    $host = !empty($_SERVER['HTTP_HOST'])
        ? (string)$_SERVER['HTTP_HOST']
        : (!empty($_SERVER['SERVER_NAME']) ? (string)$_SERVER['SERVER_NAME'] : 'localhost');

    $host = preg_replace('/[^A-Za-z0-9.\-:\[\]]/', '', $host);

    return $protocol . '://' . $host . '/';
}

$gsr_base_url = gsrExperienceBaseUrl();
$experience_switch = isset($_GET['switch_experience']) ? strtolower((string)$_GET['switch_experience']) : '';

if ($experience_switch === 'classic') {
    $experience_user_id = '';

    if (!empty($_SERVER['HTTP_REMOTE_USER'])) {
        $experience_user_id = (string)$_SERVER['HTTP_REMOTE_USER'];
    } elseif (!empty($_SERVER['HTTP_REMOTE_ADLOGON'])) {
        $experience_user_id = (string)$_SERVER['HTTP_REMOTE_ADLOGON'];
    }

    if ($experience_user_id !== '') {
        try {
            $dashboard_db->saveClassicExperiencePreference(
                $experience_user_id,
                $display_name !== '' ? $display_name : $experience_user_id,
                $gsr_base_url
            );
        } catch (Exception $e) {
            // Do not block the redirect if preference logging fails.
        }
    }

    header('Location: ' . $gsr_base_url);
    exit;
}


/* Cache for 5 minutes */
$dashboard_cache_ttl = 300;
$dashboard_cache_key = 'shared_v5_' . strtolower((string)SERVER_ENVIRONMENT) . '_' . date('Ym');
$dashboard_cached_data = gsrDashboardCacheGet($dashboard_cache_key, $dashboard_cache_ttl);
$dashboard_cache_hit = is_array($dashboard_cached_data);

/* Sidebar icons */
$menu_icon_map = array(
    'Instrument - Centric' => 'settings',
    'Customer & CSS Information' => 'groups',
    'Customer & CSS Info' => 'groups',
    'Remote Support' => 'support_agent',
    'Assay' => 'science',
    'Abbottlink' => 'link',
    'Global Service Tools' => 'build',
    'Installation &amp; Parts Data' => 'inventory_2',
    'Installation & Parts Data' => 'inventory_2',
    'Search Tools' => 'search',
    'Secondary Reports' => 'article',
    'Development Items' => 'code',
    'Reference Items' => 'menu_book',
    'PowerBI Clearinghouse' => 'analytics'
);

if ($dashboard_cache_hit) {
    $menu_data = $dashboard_cached_data['menu_data'] ?? array();
    $report_menu_lookup = $dashboard_cached_data['report_menu_lookup'] ?? array();
    $complete_report_menu_lookup = $dashboard_cached_data['complete_report_menu_lookup'] ?? array();
    $top_reports = $dashboard_cached_data['top_reports'] ?? array();
    $report_usage_counts = $dashboard_cached_data['report_usage_counts'] ?? array();
    $active_report_titles = $dashboard_cached_data['active_report_titles'] ?? array();
    $active_usage_names = $dashboard_cached_data['active_usage_names'] ?? array();
    $active_report_count = (int)($dashboard_cached_data['active_report_count'] ?? 0);
    $usage_data_loaded = !empty($dashboard_cached_data['usage_data_loaded']);
    $usage_period_label = $dashboard_cached_data['usage_period_label'] ?? '';
    $development_report_titles = $dashboard_cached_data['development_report_titles'] ?? array();
    $powerbi_dashboard_groups = $dashboard_cached_data['powerbi_dashboard_groups'] ?? array();
    $powerbi_report_count = (int)($dashboard_cached_data['powerbi_report_count'] ?? 0);
    $usage_min_period = (int)($dashboard_cached_data['usage_min_period'] ?? 0);
    $usage_max_period = (int)($dashboard_cached_data['usage_max_period'] ?? 0);
    $current_month_unique_users = (int)($dashboard_cached_data['current_month_unique_users'] ?? 0);
    $current_month_login_user_count = (int)($dashboard_cached_data['current_month_login_user_count'] ?? 0);
    $reference_report_count = (int)($dashboard_cached_data['reference_report_count'] ?? 0);
    $normal_sidebar_report_limit = max(0, 58 - $reference_report_count);
    $filter_sidebar_by_usage = true;
    $sidebar_report_limit = 58;
} else {
    /* Dashboard menu data */
    $menu_data = array();
    $report_menu_lookup = array();
    $complete_report_menu_lookup = array();
    $top_reports = array();
    $report_usage_counts = array();
    $active_report_titles = array();
    $active_usage_names = array();
    $active_report_count = 0;
    $usage_data_loaded = false;
    $usage_period_label = '';
    $development_report_titles = array();

    $filter_sidebar_by_usage = true;
    $sidebar_report_limit = 58;

try {
    $menu_rows = $dashboard_db->getMenuRows(SERVER_ENVIRONMENT);

    foreach ($menu_rows as $item) {
        $l1 = (string)($item['L1'] ?? '');
        $l2 = (int)($item['L2'] ?? 0);

        if ($l1 === '') {
            continue;
        }
        if ($l1 === '0' && $l2 === 0) {
            $menu_data['main_title'] = $item['title'] ?? 'Global Service Reports';
            continue;
        }
        if (!isset($menu_data['items'][$l1])) {
            $menu_data['items'][$l1] = array(
                'title' => 'Reports',
                'icon'  => 'folder',
                'items' => array()
            );
        }
        if ($l2 === 0) {
            $menu_data['items'][$l1]['title'] = $item['title'] ?? 'Reports';
            $menu_data['items'][$l1]['icon']  = $item['web_app_icon'] ?? 'folder';
            continue;
        }
        $menu_data['items'][$l1]['items'][] = array(
            'original_l2' => $l2,
            'title' => $item['title'] ?? '',
            'link'  => $item['link'] ?? '#',
            'target' => $item['target'] ?? '_blank',
            'desc'  => $item['description'] ?? '',
            'icon'  => $item['web_app_icon'] ?? 'description',
            'validation_icon' => $item['validation_icon'] ?? '',
            'validated_for_prod' => $item['validated_for_prod'] ?? 'N',
            'kount' => 0
        );
    }
} catch (Exception $e) {
    $menu_data = array();
}

/* Full menu lookup is also used by search and top reports. */
if (!empty($menu_data['items'])) {
    foreach ($menu_data['items'] as $group) {
        if (empty($group['items'])) {
            continue;
        }

        foreach ($group['items'] as $item) {
            $title = (string)($item['title'] ?? '');
            if ($title === '') {
                continue;
            }

            $complete_report_menu_lookup[strtolower($title)] = array(
                'title' => $title,
                'link' => $item['link'] ?? '#',
                'desc' => $item['desc'] ?? '',
                'validated_for_prod' => $item['validated_for_prod'] ?? 'N'
            );
        }
    }
}

/* Development reports are hidden from dashboard lists. */
if (!empty($menu_data['items'])) {
    foreach ($menu_data['items'] as $menu_group) {
        if (strtolower((string)($menu_group['title'] ?? '')) !== 'development items') {
            continue;
        }

        foreach (($menu_group['items'] ?? array()) as $development_item) {
            $development_title = strtolower((string)($development_item['title'] ?? ''));
            if ($development_title !== '') {
                $development_report_titles[$development_title] = true;
            }
        }
    }
}

/* Build the list used for the 58-report sidebar. */
$eligible_sidebar_menu_reports = array();
$reference_report_count = 0;
if (!empty($menu_data['items'])) {
    foreach ($menu_data['items'] as $menu_group) {
        $group_title_key = strtolower(trim((string)($menu_group['title'] ?? '')));

        if ($group_title_key === 'development items') {
            continue;
        }

        /* Reference Items count toward the sidebar total. */
        if ($group_title_key === 'reference items') {
            $reference_report_count += count($menu_group['items'] ?? array());
            continue;
        }

        foreach (($menu_group['items'] ?? array()) as $menu_item) {
            $menu_title = trim((string)($menu_item['title'] ?? ''));
            if ($menu_title === '') {
                continue;
            }

            $menu_key = strtolower($menu_title);
            if (!isset($eligible_sidebar_menu_reports[$menu_key])) {
                $eligible_sidebar_menu_reports[$menu_key] = $menu_title;
            }
        }
    }
}

/* Reserve sidebar slots for Reference Items. */
$normal_sidebar_report_limit = max(0, $sidebar_report_limit - $reference_report_count);

$powerbi_dashboard_groups = array();

try {
    $powerbi_rows = $dashboard_db->getPowerBiMenuRows(SERVER_ENVIRONMENT);
    $powerbi_group_titles = array();

    foreach ($powerbi_rows as $powerbi_item) {
        $powerbi_level_one = (string)($powerbi_item['L1'] ?? '');
        $powerbi_level_two = (int)($powerbi_item['L2'] ?? 0);

        if (!empty($powerbi_item['slide_out_side'])) {
            continue;
        }
        if ($powerbi_level_one === '0' && $powerbi_level_two === 0) {
            continue;
        }
        if ($powerbi_level_two === 0) {
            $powerbi_group_titles[$powerbi_level_one] = $powerbi_item['title'];
            if (!isset($powerbi_dashboard_groups[$powerbi_level_one])) {
                $powerbi_dashboard_groups[$powerbi_level_one] = array('title' => $powerbi_item['title'], 'items' => array());
            } else {
                $powerbi_dashboard_groups[$powerbi_level_one]['title'] = $powerbi_item['title'];
            }
            continue;
        }
        if (!isset($powerbi_dashboard_groups[$powerbi_level_one])) {
            $powerbi_dashboard_groups[$powerbi_level_one] = array(
                'title' => $powerbi_group_titles[$powerbi_level_one] ?? 'Power BI Reports',
                'items' => array()
            );
        }
        $powerbi_dashboard_groups[$powerbi_level_one]['items'][] = array(
            'title' => $powerbi_item['title'] ?? '',
            'link'  => $powerbi_item['link'] ?? '#',
            'desc'  => $powerbi_item['description'] ?? ''
        );
    }
} catch (Exception $e) {
    $powerbi_dashboard_groups = array();
}
$powerbi_report_count = 0;

foreach ($powerbi_dashboard_groups as $group) {
    $powerbi_report_count += count($group['items']);
}
/* Last three completed months */
$current_month_start = new DateTime('first day of this month 00:00:00');
$usage_start_date = clone $current_month_start;
$usage_end_date = clone $current_month_start;
$usage_start_date->modify('-3 months');
$usage_end_date->modify('-1 month');

$usage_min_period = (int)$usage_start_date->format('Ym');
$usage_max_period = (int)$usage_end_date->format('Ym');
$usage_period_label = $usage_start_date->format('M Y') . ' - ' . $usage_end_date->format('M Y');

try {
    $usage_rows = $dashboard_db->getUsageRows($usage_min_period, $usage_max_period);

    if (!empty($usage_rows)) {
        $all_report_usage_counts = array();
        $all_usage_names = array();

        foreach ($usage_rows as $row) {
            $usage_report_name = (string)($row['report'] ?? '');
            if ($usage_report_name === '') {
                continue;
            }

            $usage_key = strtolower($usage_report_name);
            $usage_count = (int)($row['kount'] ?? 0);

            if ($usage_key === '' || !empty($development_report_titles[$usage_key])) {
                continue;
            }

            if (!isset($all_report_usage_counts[$usage_key])) {
                $all_report_usage_counts[$usage_key] = 0;
                $all_usage_names[$usage_key] = $usage_report_name;
            }

            $all_report_usage_counts[$usage_key] += $usage_count;
        }

        arsort($all_report_usage_counts, SORT_NUMERIC);
        $report_usage_counts = array();
        $active_usage_names = array();

        foreach ($all_report_usage_counts as $usage_key => $usage_count) {
            if (count($report_usage_counts) >= $normal_sidebar_report_limit) {
                break;
            }
            if (!isset($eligible_sidebar_menu_reports[$usage_key])) {
                continue;
            }
            $report_usage_counts[$usage_key] = (int)$usage_count;
            $active_usage_names[] = $eligible_sidebar_menu_reports[$usage_key];
        }

        if (count($report_usage_counts) < $normal_sidebar_report_limit) {
            foreach ($eligible_sidebar_menu_reports as $menu_key => $menu_title) {
                if (count($report_usage_counts) >= $normal_sidebar_report_limit) {
                    break;
                }
                if (isset($report_usage_counts[$menu_key])) {
                    continue;
                }
                $report_usage_counts[$menu_key] = isset($all_report_usage_counts[$menu_key])
                    ? (int)$all_report_usage_counts[$menu_key]
                    : 0;
                $active_usage_names[] = $menu_title;
            }
        }

        $active_report_titles = array_fill_keys(array_keys($report_usage_counts), true);
        $active_report_count = count($report_usage_counts) + $reference_report_count;
        $usage_data_loaded = ($active_report_count > 0);
    }
} catch (Exception $e) {
    $report_usage_counts = array();
    $active_report_titles = array();
    $active_usage_names = array();
    $active_report_count = 0;
    $usage_data_loaded = false;
}

/* Apply usage filter to sidebar groups. */
if ($filter_sidebar_by_usage && $usage_data_loaded && !empty($menu_data['items'])) {
    foreach ($menu_data['items'] as $group_key => &$menu_group) {
        $group_title = (string)($menu_group['title'] ?? '');
        /* Hide Development Items. */
        if (strtolower($group_title) === 'development items') {
            unset($menu_data['items'][$group_key]);
            continue;
        }

        $keep_entire_group = (strtolower($group_title) === 'reference items');

        if (!$keep_entire_group && !empty($menu_group['items'])) {
            $menu_group['items'] = array_values(array_filter(
                $menu_group['items'],
                function ($item) use ($active_report_titles) {
                    $title_key = strtolower((string)($item['title'] ?? ''));
                    return !empty($active_report_titles[$title_key]);
                }
            ));
        }

        if (empty($menu_group['items'])) {
            unset($menu_data['items'][$group_key]);
        }
    }
    unset($menu_group);
}

/* Add usage counts and sort reports. */
if (!empty($menu_data['items'])) {
    foreach ($menu_data['items'] as $group_key => &$menu_group) {
        $menu_group['original_l1'] = $group_key;
        $menu_group['group_max_kount'] = 0;
        $menu_group['group_total_kount'] = 0;

        if (empty($menu_group['items'])) {
            continue;
        }

        foreach ($menu_group['items'] as &$item) {
            $title = (string)($item['title'] ?? '');
            $usage_key = strtolower($title);
            $item['kount'] = isset($report_usage_counts[$usage_key])
                ? (int)$report_usage_counts[$usage_key]
                : 0;

            $menu_group['group_max_kount'] = max(
                (int)$menu_group['group_max_kount'],
                (int)$item['kount']
            );
            $menu_group['group_total_kount'] += (int)$item['kount'];
        }
        unset($item);


        usort($menu_group['items'], function ($a, $b) {
            $a_kount = (int)($a['kount'] ?? 0);
            $b_kount = (int)($b['kount'] ?? 0);

            if ($a_kount !== $b_kount) {
                return $b_kount <=> $a_kount;
            }

            $a_l2 = (int)($a['original_l2'] ?? 0);
            $b_l2 = (int)($b['original_l2'] ?? 0);

            if ($a_l2 !== $b_l2) {
                return $a_l2 <=> $b_l2;
            }

            return strcmp(
                strtolower((string)($a['title'] ?? '')),
                strtolower((string)($b['title'] ?? ''))
            );
        });
    }
    unset($menu_group);

    /* Sort groups by report usage. */
    uasort($menu_data['items'], function ($a, $b) {
        /* Keep Reference Items last. */
        $special_order = array(
            'Reference Items' => 1
        );

        $a_special = $special_order[(string)($a['title'] ?? '')] ?? 0;
        $b_special = $special_order[(string)($b['title'] ?? '')] ?? 0;

        if ($a_special !== $b_special) {
            return $a_special <=> $b_special;
        }

        $a_max = (int)($a['group_max_kount'] ?? 0);
        $b_max = (int)($b['group_max_kount'] ?? 0);

        if ($a_max !== $b_max) {
            return $b_max <=> $a_max;
        }

        $a_total = (int)($a['group_total_kount'] ?? 0);
        $b_total = (int)($b['group_total_kount'] ?? 0);

        if ($a_total !== $b_total) {
            return $b_total <=> $a_total;
        }

        $a_l1 = $a['original_l1'] ?? '';
        $b_l1 = $b['original_l1'] ?? '';

        if (is_numeric($a_l1) && is_numeric($b_l1)) {
            return (int)$a_l1 <=> (int)$b_l1;
        }

        return strnatcasecmp((string)$a_l1, (string)$b_l1);
    });
}

if (!empty($menu_data['items'])) {
    foreach ($menu_data['items'] as $group) {
        if (empty($group['items'])) {
            continue;
        }

        foreach ($group['items'] as $item) {
            $title = (string)($item['title'] ?? '');

            if ($title === '') {
                continue;
            }

            $report_menu_lookup[strtolower($title)] = array(
                'title' => $title,
                'link' => $item['link'] ?? '#',
                'desc' => $item['desc'] ?? '',
                'validated_for_prod' => $item['validated_for_prod'] ?? 'N'
            );
        }
    }
}

/* Top 15 reports */
try {
    $top_report_rows = $dashboard_db->getTopReports($usage_min_period, $usage_max_period, 15);

    foreach ($top_report_rows as $row) {
        $source_report_name = (string)($row['report'] ?? '');
        if ($source_report_name === '') {
            continue;
        }

        $lookup_key = strtolower($source_report_name);
        $menu_meta = $complete_report_menu_lookup[$lookup_key] ?? array();

        $top_reports[] = array(
            'title' => $source_report_name,
            'link' => $menu_meta['link'] ?? '#',
            'desc' => $menu_meta['desc'] ?? '',
            'validated_for_prod' => $menu_meta['validated_for_prod'] ?? 'N',
            'source_report' => $source_report_name,
            'kount' => (int)($row['kount'] ?? 0)
        );
    }
} catch (Exception $e) {
    $top_reports = array();
}


    /* Dashboard KPI counts */
    $current_month_unique_users = 0;
    $current_month_login_user_count = 0;

    try {
        $current_period = (int)date('Ym');
        $month_start = date('Y-m-01 00:00:00');
        $next_month_start = date('Y-m-01 00:00:00', strtotime('first day of next month'));
        $kpi_data = $dashboard_db->getDashboardKpis($current_period, $month_start, $next_month_start);
        $current_month_unique_users = (int)($kpi_data['current_month_unique_users'] ?? 0);
        $current_month_login_user_count = (int)($kpi_data['current_month_login_user_count'] ?? 0);
    } catch (Exception $e) {
        $current_month_unique_users = 0;
        $current_month_login_user_count = 0;
    }

    gsrDashboardCacheSet($dashboard_cache_key, array(
        'menu_data' => $menu_data,
        'report_menu_lookup' => $report_menu_lookup,
        'complete_report_menu_lookup' => $complete_report_menu_lookup,
        'top_reports' => $top_reports,
        'report_usage_counts' => $report_usage_counts,
        'active_report_titles' => $active_report_titles,
        'active_usage_names' => $active_usage_names,
        'active_report_count' => $active_report_count,
        'usage_data_loaded' => $usage_data_loaded,
        'usage_period_label' => $usage_period_label,
        'development_report_titles' => $development_report_titles,
        'powerbi_dashboard_groups' => $powerbi_dashboard_groups,
        'powerbi_report_count' => $powerbi_report_count,
        'usage_min_period' => $usage_min_period,
        'usage_max_period' => $usage_max_period,
        'current_month_unique_users' => $current_month_unique_users,
        'current_month_login_user_count' => $current_month_login_user_count,
        'reference_report_count' => $reference_report_count
    ));
}

// Expose cache status in the response header.
if (!headers_sent()) {
    header('X-GSR-Dashboard-Cache: ' . ($dashboard_cache_hit ? 'HIT' : 'MISS'));
}

function renderMenuIcon($icon, $fallback = 'folder')
{
    $icon = (string)$icon;

    if ($icon !== '' && stripos($icon, '<img') !== false) {
        return $icon;
    }

    if ($icon !== '') {
        return '<span class="material-icons-outlined">' . htmlspecialchars((string)$icon, ENT_QUOTES, 'UTF-8') . '</span>';
    }

    return '<span class="material-icons-outlined">' . htmlspecialchars((string)$fallback, ENT_QUOTES, 'UTF-8') . '</span>';
}
$search_items = array();

/* Search uses the full active menu. */
if (!empty($complete_report_menu_lookup)) {
    foreach ($complete_report_menu_lookup as $menu_meta) {
        $search_title = (string)($menu_meta['title'] ?? '');
        $search_desc = (string)($menu_meta['desc'] ?? '');

        if ($search_title === '') {
            continue;
        }


        $title_key = strtolower($search_title);
        if (!empty($development_report_titles[$title_key])) {
            continue;
        }

        $search_items[] = array(
            'type' => 'Reports',
            'title' => $search_title,
            'desc' => $search_desc,
            'link' => $menu_meta['link'] ?? '#',
            'icon' => 'description',
            'validated_for_prod' => $menu_meta['validated_for_prod'] ?? 'N'
        );
    }
}
if (!empty($powerbi_dashboard_groups)) {
    foreach ($powerbi_dashboard_groups as $powerbi_group) {
        foreach (($powerbi_group['items'] ?? array()) as $powerbi_item) {
            $powerbi_title = trim((string)($powerbi_item['title'] ?? ''));

            if ($powerbi_title === '') {
                continue;
            }

            $search_items[] = array(
                'type' => 'Power BI Reports',
                'title' => $powerbi_title,
                'desc' => (string)($powerbi_item['desc'] ?? ''),
                'link' => $powerbi_item['link'] ?? '#',
                'icon' => 'analytics',
                'validated_for_prod' => 'N',
                'favorite_enabled' => false,
                'keywords' => 'powerbi power bi power bi reports powerbi clearinghouse'
            );
        }
    }
}

$user_favorites = array();
/* Favorites are loaded by gsr_favorites_ajax.php. */
?>

<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="robots" content="noindex, nofollow, noimageindex">
<meta http-equiv="X-UA-Compatible" content="IE=edge, chrome=1" />
<title>Global Service Reports (GSR)</title>
<link href="https://fonts.googleapis.com/icon?family=Material+Icons+Outlined" rel="stylesheet">
<link rel="stylesheet" href="css/style.css">
</head>
<body>
<div class="app">
<aside class="side" id="sidebar">
  <div class="side-hdr">
    <div class="abbott-logo"><svg viewBox="0 0 192 30" fill="currentColor" xmlns="http://www.w3.org/2000/svg" aria-label="Abbott"><path d="M30.97 .72H0v4.68h29.54c.91 0 1.46.61 1.46 1.51v16.18c0 .9-.55 1.51-1.46 1.51H6.14c-.91 0-1.46-.6-1.46-1.51v-6.59c0-.9.55-1.51 1.46-1.51h20.02v-4.69H4.72C2 10.31 0 12.35 0 15.03v9.54c0 2.67 2 4.72 4.72 4.72h26.27c2.72 0 4.7-2.06 4.7-4.73V5.44C35.69 2.78 33.69.71 30.97.71"/><path d="M56.04 17.44l4.46-11.95h.2l4.33 11.95h-8.99zm7.38-16.93h-4.46L50.08 24.01c-1.3 3.44-2.17 4.41-2.97 5.26v.23h6.33v-.23c-.46-.54-.61-1.24-.61-1.93 0-1.09.39-2.33.76-3.33l1.31-3.5h11.25l1.51 4.16c.31.85.5 1.62.5 2.4 0 .77-.19 1.43-.61 2.2l-.04.23h7.62v-.23c-1.18-1.2-1.83-2.51-2.55-4.45L63.43.5z"/><path d="M87.04 26.44H82.08V3.56h4.77c2.9 0 5.76.89 5.76 4.31 0 3.42-2.94 4.74-5.91 4.74h-2.44v3.05h2.55c3.28 0 7.24.89 7.24 5.37 0 4.1-3.32 5.41-7.02 5.41m3.24-12.29v-.19c4.31-.46 6.86-2.94 6.86-6.77 0-4.68-3.74-6.69-8.92-6.69H76.14v.23c.91 1 1.45 2.32 1.45 4.29v19.95c0 1.97-.54 3.28-1.45 4.29v.23h13c5.64 0 9.49-3.02 9.49-8.08 0-5.06-3.58-6.98-8.35-7.25"/><path d="M110.13 26.44h-4.96V3.56h4.77c2.9 0 5.76.89 5.76 4.31 0 3.42-2.94 4.74-5.91 4.74h-2.44v3.05h2.55c3.28 0 7.24.89 7.24 5.37 0 4.1-3.32 5.41-7.02 5.41m3.24-12.29v-.19c4.31-.46 6.86-2.94 6.86-6.77 0-4.68-3.74-6.69-8.92-6.69H99.22v.23c.92 1 1.45 2.32 1.45 4.29v19.95c0 1.97-.53 3.28-1.45 4.29v.23h13c5.64 0 9.49-3.02 9.49-8.08 0-5.06-3.58-6.98-8.35-7.25"/><path d="M137.44 26.71c-6.16 0-10.03-5.18-10.03-11.71 0-6.53 3.9-11.71 10.03-11.71 6.12 0 10.03 5.18 10.03 11.71 0 6.53-3.87 11.71-10.03 11.71zm0-26.71C128.75 0 122.69 6.46 122.69 15s6.06 15 14.75 15 14.76-6.42 14.76-15S146.13 0 137.44 0z"/><path d="M150.99.5v5.14h.22c.75-1.16 2.12-2.09 5.02-2.09h4.4v21.42c0 1.93-.5 3.29-1.41 4.29v.23h7.32v-.23c-.88-1-1.41-2.36-1.41-4.29V3.56h12.72v21.42c0 1.93-.57 3.29-1.45 4.29v.23h7.4v-.23c-.92-1-1.45-2.36-1.45-4.29V3.56h4.35c2.9 0 4.31.93 5.07 2.09h.23V.5H150.99z"/></svg></div>
    <div class="side-product">Global Service Reports</div>
  </div>
  <nav class="side-nav">
  <div>
    <a class="nav-item active" href="javascript:void(0);">
      <span class="material-icons-outlined">home</span>Home
    </a>
  </div>

  <?php if (!empty($menu_data['items'])) { ?>
    <div class="nav-grp-label">Reports</div>

 <?php
$parentIndex = 0;
foreach ($menu_data['items'] as $idx => $group) {
    $group_title = (string)($group['title'] ?? '');
    $database_group_icon = (string)($group['icon'] ?? '');

    if ($group_title === '') {
        continue;
    }

    $group_icon = $menu_icon_map[$group_title] ?? $database_group_icon;
    if ($group_icon === '') {
        $group_icon = 'folder';
    }

    $isFirst = ($parentIndex === 0);
?>
    <div class="nav-item <?php echo $isFirst ? 'expanded' : ''; ?>" data-expand>
        <?php echo renderMenuIcon($group_icon, 'folder'); ?>
        <?php echo htmlspecialchars((string)($group_title), ENT_QUOTES, 'UTF-8'); ?>
        <span class="material-icons-outlined nav-chev">chevron_right</span>
    </div>

    <?php if (!empty($group['items'])) { ?>
        <div class="nav-subs">
		
            <?php foreach ($group['items'] as $item) {
                $item_title = (string)($item['title'] ?? 'Unknown');
                $item_link  = $item['link'] ?? '#';
                $item_desc  = $item['desc'] ?? '';
            ?>
                <a class="nav-sub fav-sub draggable-report"
   draggable="true"
   target="_blank"
   href="<?php echo htmlspecialchars((string)($item_link), ENT_QUOTES, 'UTF-8'); ?>"
   data-fav-name="<?php echo htmlspecialchars((string)($item_title), ENT_QUOTES, 'UTF-8'); ?>"
   data-fav-href="<?php echo htmlspecialchars((string)($item_link), ENT_QUOTES, 'UTF-8'); ?>"
   data-fav-desc="<?php echo htmlspecialchars((string)($item_desc), ENT_QUOTES, 'UTF-8'); ?>"
   data-validated-for-prod="<?php echo htmlspecialchars((string)($item['validated_for_prod'] ?? 'N'), ENT_QUOTES, 'UTF-8'); ?>">
   <span class="material-icons-outlined nav-sub-icon">description</span>
   <?php echo htmlspecialchars((string)($item_title), ENT_QUOTES, 'UTF-8'); ?>

   <?php if (strtoupper((string)($item['validated_for_prod'] ?? 'N')) === 'Y') { ?>
       <img src="/gsr/common/images/green-check-mark-circular-64.png"
            class="validation-tick nav-validation-tick"
            width="64"
            height="64"
            alt="Validated for production"
            title="Validated for production">
   <?php } ?>

   <span class="material-icons-outlined fav-icon "
      title="Add to Favorites">
    star_border
</span>
</a>
            <?php } ?>
        </div>
    <?php } ?>

<?php
    $parentIndex++;
}
?>
  <?php } ?>

  <?php if (!empty($powerbi_dashboard_groups)) {
      $sidebar_powerbi_reports = array();
      foreach ($powerbi_dashboard_groups as $powerbi_group) {
          if (!empty($powerbi_group['items'])) {
              $sidebar_powerbi_reports = array_merge($sidebar_powerbi_reports, $powerbi_group['items']);
          }
      }
  ?>
    <div class="nav-item" data-expand>
      <span class="material-icons-outlined">analytics</span>
      Power BI Reports
      <span class="material-icons-outlined nav-chev">chevron_right</span>
    </div>
    <div class="nav-subs">
      <?php foreach ($sidebar_powerbi_reports as $powerbi_sidebar_report) { ?>
        <a class="nav-sub"
           target="_blank"
           rel="noopener noreferrer"
           href="<?php echo htmlspecialchars((string)($powerbi_sidebar_report['link'] ?? '#'), ENT_QUOTES, 'UTF-8'); ?>">
          <span class="material-icons-outlined nav-sub-icon">analytics</span>
          <?php echo htmlspecialchars((string)($powerbi_sidebar_report['title'] ?? 'Power BI Report'), ENT_QUOTES, 'UTF-8'); ?>
        </a>
      <?php } ?>
    </div>
  <?php } ?>
</nav>
  
</aside>
<div class="side-backdrop" id="sideBackdrop"></div>

<main class="main">
  <header class="top-bar">
    <button class="hamburger" id="mobileSidebarToggle" type="button"><span class="material-icons-outlined">menu</span></button>
    <div class="topbar-title">Global Service Reports</div>
   
	
	<div class="search-box" id="globalSearchBox">
    <span class="material-icons-outlined">search</span>
    <input id="globalSearchInput" type="text"
           placeholder="Search reports, instruments, categories..."
           autocomplete="off">
</div>
	
	
    <div class="topbar-spacer"></div>
    <div class="topbar-actions">
	 <a class="switch-classic-btn"
         href="?switch_experience=classic"
         title="Switch to Classic GSR">
        <span class="material-icons-outlined">swap_horiz</span>
        Switch to Classic View
      </a>
      <button class="topbar-btn" title="Help"><a href="<?php echo $gsr_base_url.'help'; ?>" target="_blank"><span class="material-icons-outlined">help_outline</span></a></button>

      
     <div class="profile-wrap" id="profileWrap">
    <a class="user-menu" href="javascript:void(0);" id="profileBtn">
        <div class="u-circle header-profile-icon-wrap">
            <span class="material-icons-outlined user-profile-icon header-profile-icon">account_circle</span>
        </div>
        <span class="user-menu-name">
            <?php echo htmlspecialchars((string)($display_name), ENT_QUOTES, 'UTF-8'); ?>
        </span>
    </a>

    <div class="profile-dropdown" id="profileDropdown">

        <div class="profile-top">
            <div class="profile-big-avatar">
                <span class="material-icons-outlined dropdown-profile-icon">account_circle</span>
            </div>

            <div class="profile-top-info">
                <div class="profile-name">
                    <?php echo htmlspecialchars((string)($display_name), ENT_QUOTES, 'UTF-8'); ?>
                </div>

                <div class="profile-email">
                    <?php echo htmlspecialchars((string)($_SERVER['HTTP_REMOTE_EMAIL'] ?? ''), ENT_QUOTES, 'UTF-8'); ?>
                </div>
            </div>
        </div>

        <div class="profile-role">
            <span class="material-icons-outlined">admin_panel_settings</span>
            <?php echo htmlspecialchars((string)($_SESSION['azure_auth_employeeType'] ?? ''), ENT_QUOTES, 'UTF-8'); ?>
        </div>

        <div class="profile-bottom">
            <div class="profile-logo"><img width='100px' src='/gsr/common/images/abbottNewLogo.png'></div>

            <a class="signout-btn" href="<?php echo htmlspecialchars((string)($logout_url), ENT_QUOTES, 'UTF-8'); ?>">
                <span class="material-icons-outlined">logout</span>
                Sign out
            </a>
        </div>

    </div>
</div>
    </div>
  </header>
  <div class="search-modal-overlay" id="searchModalOverlay"></div>

<div class="search-modal" id="searchModal">
    <div class="search-modal-body" id="searchModalBody"></div>
</div>
<?php 
$parent_group_count = count($menu_data['items'] ?? array());

$child_report_count = 0;
foreach (($menu_data['items'] ?? array()) as $group) {
    $child_report_count += count($group['items'] ?? array());
}

/* Active GSR count is based on qualifying usage-report names from the last
   three completed months. Development Items and Power BI reports are excluded.
   Fall back to the visible GSR menu child count if the usage query is unavailable. */
$display_report_count = $usage_data_loaded
    ? $active_report_count
    : $child_report_count;

$last_login_time = '';
if (!empty($_SESSION['azure_auth_IssueInstant'])) {
    $dt = new DateTime($_SESSION['azure_auth_IssueInstant']);
    $dt->setTimezone(new DateTimeZone(date_default_timezone_get()));
    $last_login_time = $dt->format('d M Y, h:i A T');
}
?>
  <div class="page">
    <section class="hero">
      <div class="hero-content">
        <h1 class="hero-greeting">Hello, <strong><?php echo htmlspecialchars((string)($display_name), ENT_QUOTES, 'UTF-8'); ?>.</strong></h1>
        <div class="hero-sub" id="heroDate"></div>
        <div class="hero-stats">
          <div class="hero-stat"
               title="Usage logic: <?php echo htmlspecialchars((string)($usage_period_label), ENT_QUOTES, 'UTF-8'); ?>">
            <div class="hero-stat-val">
              <?php echo number_format($display_report_count); ?>
            </div>
            <div class="hero-stat-label">Active Reports</div>
          </div>
		 
			<div class="hero-stat" id="powerbiReportCard">
				<div class="hero-stat-val">
					<?php echo number_format($powerbi_report_count); ?>
				</div>
				<div class="hero-stat-label">
					POWER BI Reports
				</div>
			</div>
		 
          <div class="hero-stat">
			<div class="hero-stat-val">
				<?php echo number_format($current_month_unique_users); ?>
			</div>
			<div class="hero-stat-label">Monthly Active Users</div>
		</div>
		 <div class="hero-stat">
			<div class="hero-stat-val">
				<?php echo htmlspecialchars((string)($current_month_login_user_count), ENT_QUOTES, 'UTF-8'); ?>
			</div>
			<div class="hero-stat-label">Users Logged in Current Month</div>
		</div>
         
          <div class="hero-stat">
			<div class="hero-stat-val">
				<?php echo htmlspecialchars((string)($last_login_time), ENT_QUOTES, 'UTF-8'); ?>
			</div>
			<div class="hero-stat-label">Last Login Time</div>
		</div>
        </div>
      </div>
    </section>
	
    <section>
	<div class="sec-hdr"><h2><span class="material-icons-outlined">star</span>Favorites</h2></div>
      
	  <div class="fav-grid" id="favoritesBody"></div>
    </section>

	 <?php if (!empty($top_reports)) { ?>
    <section class="section">
      <div class="sec-hdr"><h2 title="For last 3 months"><span class="material-icons-outlined">trending_up</span>Top 15 Used Reports</h2></div>
      <div class="rpt-grid">
        <?php
          $tileClasses = array('t-blue','t-green','t-amber','t-purple','t-cyan','t-red');
          $i = 0;
          foreach ($top_reports as $report) {
            $tile = $tileClasses[$i % count($tileClasses)];
            $i++;
            $title = $report['title'] ?? '';
            $desc = $report['desc'] ?? '';
            $link = $report['link'] ?? '#';
            $count = (int)($report['kount'] ?? 0);
            $validatedForProd = strtoupper((string)($report['validated_for_prod'] ?? 'N'));
        ?>
       
		  
		  
		  <?php
		$reportIcons = array(
			'Instrument Search' => 'manage_search',
			'Service Capacity Model' => 'speed',
			'Country Reports' => 'public',
			'Ticket Search' => 'confirmation_number',
			'CRL Management Report' => 'assignment',
			'TSB Viewer' => 'article',
			'Parts Viewer' => 'precision_manufacturing',
			'Assay Report' => 'science',
			'SIFT Viewer' => 'visibility',
			'Contact Center Reports' => 'support_agent',
			'Service Contract Viewer' => 'description',
			'Service Manager Reports' => 'supervisor_account',
			'Installed Base Viewer' => 'inventory_2',
			'FASTR' => 'bolt',
			'Timeliness Viewer' => 'schedule',
			'Installation Metrics' => 'construction',
			'Service Business Review' => 'analytics',
			'Uptime' => 'trending_up'
		);

		$iconName = $reportIcons[$title] ?? 'dashboard';
		?>

<a class="rpt-card top-report-card"
   target="_blank"
   href="<?php echo htmlspecialchars((string)($link), ENT_QUOTES, 'UTF-8'); ?>"
   data-title="<?php echo htmlspecialchars((string)($title), ENT_QUOTES, 'UTF-8'); ?>"
   data-fav-name="<?php echo htmlspecialchars((string)($title), ENT_QUOTES, 'UTF-8'); ?>"
   data-fav-href="<?php echo htmlspecialchars((string)($link), ENT_QUOTES, 'UTF-8'); ?>"
   data-fav-desc="<?php echo htmlspecialchars((string)($desc), ENT_QUOTES, 'UTF-8'); ?>"
   data-validated-for-prod="<?php echo htmlspecialchars((string)($validatedForProd), ENT_QUOTES, 'UTF-8'); ?>">
  <div class="rpt-ico rpt-ico-<?php echo $i % 6; ?>">
    <span class="material-icons-outlined"><?php echo htmlspecialchars((string)($iconName), ENT_QUOTES, 'UTF-8'); ?></span>
  </div>
  <span><?php echo htmlspecialchars((string)($title), ENT_QUOTES, 'UTF-8'); ?></span>
  <?php if ($validatedForProd === 'Y') { ?>
      <img src="/gsr/common/images/green-check-mark-circular-64.png"
           class="validation-tick top-report-validation-tick"
           width="64"
           height="64"
           alt="Validated for production"
           title="Validated for production">
  <?php } ?>
  <span class="material-icons-outlined top-report-fav-star "
        title="Add to Favorites">
      star_border
  </span>
</a>
        <?php } ?>
      </div>
    </section>
    <?php } ?>
	<?php
$all_powerbi_reports = array();

foreach ($powerbi_dashboard_groups as $group) {

    if (!empty($group['items'])) {
        $all_powerbi_reports = array_merge($all_powerbi_reports, $group['items']);
    }

}
?>
	<section class="panel-bi" id="powerbi-clearinghouse">

		<div class="sec-hdr pi-head">
			<h2>
				<span class="material-icons-outlined">analytics</span>
				Power BI Reports (May need access)
			</h2>
		</div>

		<?php if (!empty($all_powerbi_reports)) { ?>

			<div class="rpt-grid">

				<?php foreach ($all_powerbi_reports as $powerbi_report) { ?>

					<a class="rpt-card"
					   target="_blank"
					   rel="noopener noreferrer"
					   href="<?php echo htmlspecialchars((string)($powerbi_report['link']), ENT_QUOTES, 'UTF-8'); ?>"
					   data-title="<?php echo htmlspecialchars((string)($powerbi_report['title']), ENT_QUOTES, 'UTF-8'); ?>">

						<div class="rpt-ico">
							<span class="material-icons-outlined">analytics</span>
						</div>

						<span>
							<?php echo htmlspecialchars((string)($powerbi_report['title']), ENT_QUOTES, 'UTF-8'); ?>
						</span>

					</a>

				<?php } ?>

			</div>

		<?php } else { ?>

			<div class="empty">
				No active Power BI Reports found.
			</div>

		<?php } ?>

	</section>
    <div class="bottom">
      <div class="panel">
		  <div class="panel-hdr">
			<h3><span class="material-icons-outlined">history</span>Recently Viewed</h3>
			<a class="sec-link" href="javascript:void(0);" id="clearRecentViews">Clear</a>
		  </div>
		  <div class="panel-body" id="recentlyViewedBody"></div>
		</div>
      <div class="panel"><div class="panel-hdr"><h3><span class="material-icons-outlined">bolt</span>Quick Access</h3></div><div class="panel-body">
        
        <a class="ql" href="<?php echo $gsr_base_url.'help'; ?>"><div class="ql-ico ql-ico-help"><span class="material-icons-outlined">support</span></div><div class="ql-text"><strong>Help &amp; Documentation</strong><small>Guides, FAQs, training</small></div><span class="material-icons-outlined ql-arr">arrow_forward</span></a>
        <a class="ql" href="https://abbott.sharepoint.com/sites/GLB-ADD-MyGSS" target="_blank" rel="noopener noreferrer"><div class="ql-ico ql-ico-gss"><span class="material-icons-outlined">business_center</span></div><div class="ql-text"><strong>My GSS</strong><small>Global Service Support</small></div><span class="material-icons-outlined ql-arr">arrow_forward</span></a>
      </div></div>
    </div>
  </div>
  <footer class="app-footer"><div class="footer-left"><svg viewBox="0 0 192 30" fill="currentColor" xmlns="http://www.w3.org/2000/svg"><path d="M30.97 .72H0v4.68h29.54c.91 0 1.46.61 1.46 1.51v16.18c0 .9-.55 1.51-1.46 1.51H6.14c-.91 0-1.46-.6-1.46-1.51v-6.59c0-.9.55-1.51 1.46-1.51h20.02v-4.69H4.72C2 10.31 0 12.35 0 15.03v9.54c0 2.67 2 4.72 4.72 4.72h26.27c2.72 0 4.7-2.06 4.7-4.73V5.44C35.69 2.78 33.69.71 30.97.71"/><path d="M56.04 17.44l4.46-11.95h.2l4.33 11.95h-8.99zm7.38-16.93h-4.46L50.08 24.01c-1.3 3.44-2.17 4.41-2.97 5.26v.23h6.33v-.23c-.46-.54-.61-1.24-.61-1.93 0-1.09.39-2.33.76-3.33l1.31-3.5h11.25l1.51 4.16c.31.85.5 1.62.5 2.4 0 .77-.19 1.43-.61 2.2l-.04.23h7.62v-.23c-1.18-1.2-1.83-2.51-2.55-4.45L63.43.5z"/><path d="M87.04 26.44H82.08V3.56h4.77c2.9 0 5.76.89 5.76 4.31 0 3.42-2.94 4.74-5.91 4.74h-2.44v3.05h2.55c3.28 0 7.24.89 7.24 5.37 0 4.1-3.32 5.41-7.02 5.41m3.24-12.29v-.19c4.31-.46 6.86-2.94 6.86-6.77 0-4.68-3.74-6.69-8.92-6.69H76.14v.23c.91 1 1.45 2.32 1.45 4.29v19.95c0 1.97-.54 3.28-1.45 4.29v.23h13c5.64 0 9.49-3.02 9.49-8.08 0-5.06-3.58-6.98-8.35-7.25"/><path d="M110.13 26.44h-4.96V3.56h4.77c2.9 0 5.76.89 5.76 4.31 0 3.42-2.94 4.74-5.91 4.74h-2.44v3.05h2.55c3.28 0 7.24.89 7.24 5.37 0 4.1-3.32 5.41-7.02 5.41m3.24-12.29v-.19c4.31-.46 6.86-2.94 6.86-6.77 0-4.68-3.74-6.69-8.92-6.69H99.22v.23c.92 1 1.45 2.32 1.45 4.29v19.95c0 1.97-.53 3.28-1.45 4.29v.23h13c5.64 0 9.49-3.02 9.49-8.08 0-5.06-3.58-6.98-8.35-7.25"/><path d="M137.44 26.71c-6.16 0-10.03-5.18-10.03-11.71 0-6.53 3.9-11.71 10.03-11.71 6.12 0 10.03 5.18 10.03 11.71 0 6.53-3.87 11.71-10.03 11.71zm0-26.71C128.75 0 122.69 6.46 122.69 15s6.06 15 14.75 15 14.76-6.42 14.76-15S146.13 0 137.44 0z"/><path d="M150.99.5v5.14h.22c.75-1.16 2.12-2.09 5.02-2.09h4.4v21.42c0 1.93-.5 3.29-1.41 4.29v.23h7.32v-.23c-.88-1-1.41-2.36-1.41-4.29V3.56h12.72v21.42c0 1.93-.57 3.29-1.45 4.29v.23h7.4v-.23c-.92-1-1.45-2.36-1.45-4.29V3.56h4.35c2.9 0 4.31.93 5.07 2.09h.23V.5H150.99z"/></svg><span>&copy; 2026 Abbott. All Rights Reserved.</span></div></footer>
</main>
</div>


<script type="application/json" id="gsrSearchData"><?php echo json_encode($search_items, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT); ?></script>
<script src="js/script.js"></script>
</body>
</html>
