<?php
/** GSR dashboard database methods */
class gsr_dashboard_class
{
    private function sqlValue($value)
    {
        return str_replace("'", "''", trim((string)$value));
    }

    private function environmentConfig($environment)
    {
        switch (strtoupper((string)$environment)) {
            case 'DEV':
                return array('active' => 'dev_active', 'link' => 'dev_link');
            case 'TEST':
                return array('active' => 'test_active', 'link' => 'test_link');
            case 'QA':
                return array('active' => 'qa_active', 'link' => 'qa_link');
            case 'PROD':
            default:
                return array('active' => 'prod_active', 'link' => 'prod_link');
        }
    }

    public function saveClassicExperiencePreference($userId, $userName, $clickedUrl)
    {
        $db = new gsr_sqlsrv_db_class('gsr_write');
        $userId = $this->sqlValue($userId);
        $userName = $this->sqlValue($userName);
        $clickedUrl = $this->sqlValue($clickedUrl);

        $db->run_sql_save_with_exit_on_error(
            "SELECT id FROM [GSR_ADMIN].[dbo].[GSR_USER_EXPERIENCE_PREFERENCE] WHERE user_id = '{$userId}'"
        );
        $existing = $db->fetch_array_assoc();

        if (!empty($existing)) {
            $db->run_sql_save_with_exit_on_error(
                "UPDATE [GSR_ADMIN].[dbo].[GSR_USER_EXPERIENCE_PREFERENCE]
                 SET user_name = '{$userName}',
                     clicked_datetime = GETDATE(),
                     clicked_url = '{$clickedUrl}',
                     clicked_status = 0
                 WHERE user_id = '{$userId}'"
            );
        } else {
            $db->run_sql_save_with_exit_on_error(
                "INSERT INTO [GSR_ADMIN].[dbo].[GSR_USER_EXPERIENCE_PREFERENCE]
                    (user_id, user_name, clicked_datetime, clicked_url, clicked_status)
                 VALUES ('{$userId}', '{$userName}', GETDATE(), '{$clickedUrl}', 0)"
            );
        }
    }

    public function getMenuRows($environment)
    {
        $config = $this->environmentConfig($environment);
        $db = new sqlsrv_db_class();
        $sql = "SELECT
                    COALESCE(slide_out_side, CAST([L1] AS varchar)) AS L1,
                    COALESCE(slide_out_order, [L2]) AS L2,
                    [web_app_icon],
                    [title],
                    [validation_icon],
                    [validated_for_prod],
                    {$config['link']} AS link,
                    [target],
                    [description],
                    [submit_request],
                    slide_out_side,
                    slide_out_order
                FROM [GSR_ADMIN].[dbo].[GSR_ADMIN_GUI_MENUS]
                WHERE {$config['active']} = 1
                ORDER BY
                    CASE WHEN slide_out_side IS NULL THEN 0 ELSE 1 END,
                    TRY_CONVERT(int, [L1]),
                    [L1], [L2], slide_out_side, slide_out_order";

        $db->run_sql_save_with_exit_on_error($sql);
        return $db->fetch_array_assoc();
    }

    public function getPowerBiMenuRows($environment)
    {
        $config = $this->environmentConfig($environment);
        $db = new sqlsrv_db_class();
        $sql = "SELECT
                    COALESCE(slide_out_side, CAST([L1] AS varchar)) AS L1,
                    COALESCE(slide_out_order, [L2]) AS L2,
                    [title], [link], [description], slide_out_side
                FROM [GSR_ADMIN].[dbo].[PBI_ADMIN_GUI_MENUS]
                WHERE {$config['active']} = 1
                ORDER BY slide_out_side, slide_out_order, [L1], [L2]";

        $db->run_sql_save_with_exit_on_error($sql);
        return $db->fetch_array_assoc();
    }

    public function getUsageRows($minPeriod, $maxPeriod)
    {
        $db = new gsr_sqlsrv_db_class('gsr_read_prod');
        $schemaSql = "SELECT LOWER(COLUMN_NAME) AS column_name
                      FROM GSR.INFORMATION_SCHEMA.COLUMNS
                      WHERE TABLE_SCHEMA = 'dbo'
                        AND TABLE_NAME = 'GSR_USE_LOGS_ROLLUP'";
        $schemaResult = $db->run_sql_with_exit_on_error($schemaSql);
        $columns = array();

        if ($db->sqlsrv_has_rows($schemaResult)) {
            foreach ($db->fetch_array_assoc($schemaResult) as $row) {
                $name = strtolower((string)($row['column_name'] ?? ''));
                if ($name !== '') {
                    $columns[$name] = true;
                }
            }
        }

        foreach (array('period', 'gsr_report_level_1', 'gsr_report_level_2', 'adlogon', 'kount') as $required) {
            if (empty($columns[$required])) {
                throw new Exception('Missing required GSR_USE_LOGS_ROLLUP column: ' . $required);
            }
        }

        $minPeriod = (int)$minPeriod;
        $maxPeriod = (int)$maxPeriod;
        $filters = array(
            "period BETWEEN {$minPeriod} AND {$maxPeriod}",
            "UPPER(LTRIM(RTRIM(ISNULL(gsr_report_level_1, '')))) NOT IN ('GSR HOME', 'HELP')",
            "NULLIF(LTRIM(RTRIM(ISNULL(gsr_report_level_2, ''))), '') IS NULL",
            "UPPER(LTRIM(RTRIM(ISNULL(adlogon, '')))) <> 'LONGYX2'",
            "NULLIF(LTRIM(RTRIM(ISNULL(gsr_report_level_1, ''))), '') IS NOT NULL"
        );

        if (!empty($columns['ft_type'])) {
            $filters[] = "UPPER(LTRIM(RTRIM(ISNULL(ft_type, '')))) IN ('AMB', 'MGR', 'TSO', 'FSE')";
        }
        if (!empty($columns['division'])) {
            $filters[] = "(division IS NULL OR UPPER(LTRIM(RTRIM(division))) NOT IN ('AMD', 'ATM', 'ADI'))";
        }
        if (!empty($columns['allow_deny'])) {
            $filters[] = "UPPER(LTRIM(RTRIM(ISNULL(allow_deny, '')))) = 'ALLOW'";
        }

        $sql = "SELECT
                    LTRIM(RTRIM(gsr_report_level_1)) AS report,
                    SUM(ISNULL(kount, 0)) AS kount,
                    COUNT(DISTINCT LTRIM(RTRIM(adlogon))) AS user_count
                FROM GSR.dbo.GSR_USE_LOGS_ROLLUP
                WHERE " . implode(" AND ", $filters) . "
                GROUP BY LTRIM(RTRIM(gsr_report_level_1))
                ORDER BY SUM(ISNULL(kount, 0)) DESC,
                         LTRIM(RTRIM(gsr_report_level_1)) ASC";
						

        $result = $db->run_sql_with_exit_on_error($sql);
        return $db->sqlsrv_has_rows($result) ? $db->fetch_array_assoc($result) : array();
    }

    public function getTopReports($minPeriod, $maxPeriod, $limit = 15)
    {
        $db = new gsr_sqlsrv_db_class('gsr_read_prod');
        $minPeriod = (int)$minPeriod;
        $maxPeriod = (int)$maxPeriod;
        $limit = max(1, (int)$limit);
        $sql = "SELECT TOP {$limit}
                    LTRIM(RTRIM(gsr_report_level_1)) AS report,
                    SUM(kount) AS kount
                FROM GSR.dbo.GSR_USE_LOGS_ROLLUP
                WHERE gsr_report_level_2 IS NULL
                  AND period BETWEEN {$minPeriod} AND {$maxPeriod}
                  AND gsr_report_level_1 <> 'GSR HOME'
                GROUP BY gsr_report_level_1
                ORDER BY SUM(kount) DESC";

        $result = $db->run_sql_with_exit_on_error($sql);
        return $db->sqlsrv_has_rows($result) ? $db->fetch_array_assoc($result) : array();
    }

    public function getDashboardKpis($currentPeriod, $monthStart, $nextMonthStart)
    {
        $db = new gsr_sqlsrv_db_class('gsr_read_prod');
        $currentPeriod = (int)$currentPeriod;
        $monthStart = $this->sqlValue($monthStart);
        $nextMonthStart = $this->sqlValue($nextMonthStart);

        $activeUsers = 0;
        $loginUsers = 0;

        $activeSql = "SELECT COUNT(DISTINCT LTRIM(RTRIM(adlogon))) AS active_user_count
                      FROM GSR.dbo.GSR_USE_LOGS_ROLLUP
                      WHERE period = {$currentPeriod}
                        AND adlogon IS NOT NULL
                        AND LTRIM(RTRIM(adlogon)) <> ''";
        $activeResult = $db->run_sql_with_exit_on_error($activeSql);
        if ($db->sqlsrv_has_rows($activeResult)) {
            $rows = $db->fetch_array_assoc($activeResult);
            $activeUsers = (int)($rows[0]['active_user_count'] ?? 0);
        }

        $loginSql = "SELECT COUNT(DISTINCT LTRIM(RTRIM(adlogon))) AS login_user_count
                     FROM GSR.dbo.GSR_USE_LOGS
                     WHERE date_time >= '{$monthStart}'
                       AND date_time < '{$nextMonthStart}'
                       AND adlogon IS NOT NULL
                       AND LTRIM(RTRIM(adlogon)) <> ''";
        $loginResult = $db->run_sql_with_exit_on_error($loginSql);
        if ($db->sqlsrv_has_rows($loginResult)) {
            $rows = $db->fetch_array_assoc($loginResult);
            $loginUsers = (int)($rows[0]['login_user_count'] ?? 0);
        }

        return array(
            'current_month_unique_users' => $activeUsers,
            'current_month_login_user_count' => $loginUsers
        );
    }
}
